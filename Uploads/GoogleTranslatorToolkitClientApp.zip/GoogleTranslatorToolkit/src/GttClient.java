import com.google.gdata.client.gtt.*;
import com.google.gdata.client.gtt.DocumentQuery;
import com.google.gdata.data.gtt.*;
import com.google.gdata.util.*;

import java.io.IOException;
import java.net.URL;

/**
 * @author Leniel Macaferi
 * @date 12-11-2010
 */
public class GttClient
{

	static final String DOCUMENTS_FEED_URI = "http://translate.google.com/toolkit/feeds/documents";

	public static void main(String[] args) throws IOException, ServiceException
	{
		try
		{
			GttService myService = new GttService("GoogleTranslatorToolkitClientApp");

			// Your Google username and password go here...
			myService.setUserCredentials("YourGoogleEmailAddress", "YourPassword");

			URL feedUrl = new URL(DOCUMENTS_FEED_URI);

			DocumentQuery query = new DocumentQuery(feedUrl);

			// Send the query to the server.
			DocumentFeed resultFeed = myService.getFeed(query, DocumentFeed.class);

			printResults(resultFeed);
		}
		catch (AuthenticationException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Iterates the document feed and print some information to the console screen.
	 * @param resultFeed
	 */
	private static void printResults(DocumentFeed resultFeed)
	{
		int i = 1;
		int totalWords = 0;

		for (DocumentEntry entry : resultFeed.getEntries())
		{
			System.out.println(String.valueOf(i++) +  ") "
					+ "id = " + entry.getId().substring(DOCUMENTS_FEED_URI.length() + 1)
					+ ", title = '" + entry.getTitle().getPlainText() + "'"
					+ ", number of words = '" + entry.getNumberOfSourceWords().getValue() + "'");

			totalWords += entry.getNumberOfSourceWords().getValue();
		}

		// Here's where I satisfy my curiosity... :D
		System.out.println("Total words translated so far = " + totalWords);
	}
}
