﻿using ReflectionWebApp.Interfaces;
using System.Reflection;
using System.Web.UI.MobileControls;
using System.Collections.Generic;
using ReflectionWebApp.Util;

namespace ReflectionWebApp.Presenters
{
    public class MyPresenter : BasePresenter<IMyView>
    {
        public MyPresenter()
        {

        }

        #region Overrides of BasePresenter<IMyView>

        /// <summary>
        /// Subscribe the Presenter to View events
        /// </summary>
        protected override void SubscribePresenterToViewEvents()
        {
            view.FirstLoading += FirstLoading;
        }

        /// <summary>
        /// Specific FirstLoading implemented by each inheritor
        /// </summary>
        protected override void FirstLoading()
        {
            view.MyMethod();

            // Useful technique to avoid calling 10 lines of code.
            for (int i = 1; i <= 10; i++)
            {
                ReflectionUtil.BindProperty(view, string.Format("TextBox{0}Text", i), (i * i).ToString());
            }

            // Useful technique to avoid writing methods almost identical just to change a method call.
            for (int i = 1; i <= 2; i++)
            {
                // Do some common logic here...

                ReflectionUtil.BindMethod(view, string.Format("WriteToPage{0}", i), new object[] { new List<object> { i * 2, i * 3, i * 4, i * 5 } });

                // Do some common logic here...
            }
        }

        #endregion
    }
}
