﻿namespace ReflectionWebApp.Interfaces
{
    public interface IBaseView
    {

    }
}
