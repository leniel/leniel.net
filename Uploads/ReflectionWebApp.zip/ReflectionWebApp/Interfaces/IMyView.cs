﻿using System;
using System.Collections.Generic;

namespace ReflectionWebApp.Interfaces
{
    public interface IMyView : IBaseView
    {
        event EventHandler FirstLoading;

        void MyMethod();

        string TextBox1Text { set; }
        string TextBox2Text { set; }
        string TextBox3Text { set; }
        string TextBox4Text { set; }
        string TextBox5Text { set; }
        string TextBox6Text { set; }
        string TextBox7Text { set; }
        string TextBox8Text { set; }
        string TextBox9Text { set; }
        string TextBox10Text { set; }

        void WriteToPage1(List<object> values);
        void WriteToPage2(List<object> values);
    }
}
