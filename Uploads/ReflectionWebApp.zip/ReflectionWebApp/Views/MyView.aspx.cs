﻿using System;
using System.Web.UI;
using ReflectionWebApp.Interfaces;
using ReflectionWebApp.Presenters;
using System.Collections.Generic;

namespace ReflectionWebApp.Views
{
    public partial class MyView : Page, IMyView
    {
        private MyPresenter presenter;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Inversion of Control
            presenter = IoC.Resolve<MyPresenter>();
            presenter.RegisterView(this);

            if(!IsPostBack)
            {
                if(FirstLoading != null)
                {
                    FirstLoading(this, EventArgs.Empty);
                }
            }
        }

        #region Implementation of IMyView

        public event EventHandler FirstLoading;

        public void MyMethod()
        {
            Response.Write("Reflection power" + Environment.NewLine);
        }

        #region TextBoxes

        public string TextBox1Text
        {
            set
            {
                TextBox1.Text = value;
            }
        }

        public string TextBox2Text
        {
            set
            {
                TextBox2.Text = value;
            }
        }

        public string TextBox3Text
        {
            set
            {
                TextBox3.Text = value;
            }
        }

        public string TextBox4Text
        {
            set
            {
                TextBox4.Text = value;
            }
        }

        public string TextBox5Text
        {
            set
            {
                TextBox5.Text = value;
            }
        }

        public string TextBox6Text
        {
            set
            {
                TextBox6.Text = value;
            }
        }

        public string TextBox7Text
        {
            set
            {
                TextBox7.Text = value;
            }
        }

        public string TextBox8Text
        {
            set
            {
                TextBox8.Text = value;
            }
        }

        public string TextBox9Text
        {
            set
            {
                TextBox9.Text = value;
            }
        }

        public string TextBox10Text
        {
            set
            {
                TextBox10.Text = value;
            }
        }

        #endregion

        #region Methods

        public void WriteToPage1(List<object> values)
        {
            GridView1.DataSource = values;
            GridView1.DataBind();
        }

        public void WriteToPage2(List<object> values)
        {
            GridView2.DataSource = values;
            GridView2.DataBind();
        }

        #endregion

        #endregion
    }
}
