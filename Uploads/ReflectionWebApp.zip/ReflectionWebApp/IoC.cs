﻿using System;
using Castle.Windsor;

namespace ReflectionWebApp
{
    public static class IoC
    {
        private static IWindsorContainer container;

        public static void Initialize(IWindsorContainer aContainer)
        {
            container = aContainer;
        }

        public static T Resolve<T>()
        {
            try
            {
                return container.Resolve<T>();
            }
            catch(Exception e)
            {
                throw e;
            }
        }
    }
}