﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;

namespace ReflectionWebApp.Util
{
    /// <summary>
    /// Utility class for Reflection operations.
    /// </summary>
    public class ReflectionUtil
    {
        /// <summary>
        /// Sets a value to a property through the use of Reflection.
        /// </summary>
        /// <param name="obj">Object that owns the property</param>
        /// <param name="propertyName">Property name</param>
        /// <param name="propertyValue">Value to be set</param>
        public static void BindProperty(object obj, string propertyName, object propertyValue)
        {
            // Getting the property I want to use.
            PropertyInfo propertyInfo = obj.GetType().GetProperty(propertyName);

            // Verifying if the property was acquired with success.
            if (propertyInfo != null && propertyInfo.CanWrite)
            {
                // Set the property value.
                propertyInfo.SetValue(obj, propertyValue, null);
            }
        }

        /// <summary>
        /// Calls a method through the use of Reflection.
        /// </summary>
        /// <param name="obj">Object that owns the method</param>
        /// <param name="methodName">Method name</param>
        /// <param name="methodParameters">Method parameters</param>
        public static void BindMethod(object obj, string methodName, object[] methodParameters)
        {
            // Getting the method I want to use.
            MethodInfo methodInfo = obj.GetType().GetMethod(methodName);

            if (methodInfo != null)
            {        // Call/Invoke the method with the desired parameters. 
                methodInfo.Invoke(obj, methodParameters);
            }
        }
    }
}