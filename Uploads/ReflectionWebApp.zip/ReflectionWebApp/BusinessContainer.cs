﻿using Castle.Core;
using Castle.Windsor;
using ReflectionWebApp.Presenters;

namespace ReflectionWebApp
{
    public class BusinessContainer : WindsorContainer
    {
        public BusinessContainer()
        {
            RegisterComponents();
        }

        private void RegisterComponents()
        {
            // Presenters
            AddComponentWithLifestyle("MyPresenter.presenter", typeof(MyPresenter), LifestyleType.Transient);
        }
    }
}
