﻿//
//	Depth and Breadth First Search algorithms - C# Sample Application
//	By Leniel Braz de Oliveira Macaferi & Wellington Magalhães Leite - 2007.
//
//  UBM Computer Engineering course - 9th term [http://www.ubm.br/]
//  This program sample was developed and turned in as a term paper for the
//  Artificial Intelligence discipline.
//  The source code is provided "as is" without warranty.
//
//  Author:
//  http://lenielmacaferi.blogspot.com/2008/01/breadth-and-depth-first-search.html
//
//  This code uses some classes from the following package:
//  http://download.microsoft.com/download/e/5/f/e5f82108-9c06-496b-a13a-38bba77c7b2b/graphs.msi
//  
//  See this link for more details:
//  http://msdn2.microsoft.com/en-us/library/aa289152(VS.71).aspx
//  
//  Theory:
//  http://ai-depot.com/Tutorial/PathFinding-Blind.html

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using skmDataStructures.Graph;

namespace BreadthDepthFirstSearch
{
  class Program
  {
    static void Main(string[] args)
    {
      Pathfinding pathFinding = new Pathfinding();

      Node start, end;

      // Vertexes
      pathFinding.Graph.AddNode("Arad", null);
      pathFinding.Graph.AddNode("Bucharest", null);
      pathFinding.Graph.AddNode("Craiova", null);
      pathFinding.Graph.AddNode("Dobreta", null);
      pathFinding.Graph.AddNode("Eforie", null);
      pathFinding.Graph.AddNode("Fagaras", null);
      pathFinding.Graph.AddNode("Giurgiu", null);
      pathFinding.Graph.AddNode("Hirsova", null);
      pathFinding.Graph.AddNode("Iasi", null);
      pathFinding.Graph.AddNode("Lugoj", null);
      pathFinding.Graph.AddNode("Mehadia", null);
      pathFinding.Graph.AddNode("Neamt", null);
      pathFinding.Graph.AddNode("Oradea", null);
      pathFinding.Graph.AddNode("Pitesti", null);
      pathFinding.Graph.AddNode("Rimnicu Vilcea", null);
      pathFinding.Graph.AddNode("Sibiu", null);
      pathFinding.Graph.AddNode("Timisoara", null);
      pathFinding.Graph.AddNode("Urziceni", null);
      pathFinding.Graph.AddNode("Vaslui", null);
      pathFinding.Graph.AddNode("Zerind", null);

      // Edges

      // Arad <-> Zerind
      pathFinding.Graph.AddUndirectedEdge("Arad", "Zerind", 75);
      // Arad <-> Timisoara
      pathFinding.Graph.AddUndirectedEdge("Arad", "Timisoara", 118);
      // Arad <-> Sibiu
      pathFinding.Graph.AddUndirectedEdge("Arad", "Sibiu", 140);

      // Bucharest <-> Urziceni
      pathFinding.Graph.AddUndirectedEdge("Bucharest", "Urziceni", 85);
      // Bucharest <-> Giurgiu
      pathFinding.Graph.AddUndirectedEdge("Bucharest", "Giurgiu", 90);
      // Bucharest <-> Pitesti
      pathFinding.Graph.AddUndirectedEdge("Bucharest", "Pitesti", 101);
      // Bucharest <-> Fagaras
      pathFinding.Graph.AddUndirectedEdge("Bucharest", "Fagaras", 211);

      // Craiova <-> Dobreta
      pathFinding.Graph.AddUndirectedEdge("Craiova", "Dobreta", 120);
      // Craiova <-> Pitesti
      pathFinding.Graph.AddUndirectedEdge("Craiova", "Pitesti", 138);
      // Craiova <-> Rimnicu Vilcea
      pathFinding.Graph.AddUndirectedEdge("Craiova", "Rimnicu Vilcea", 146);

      // Dobreta <-> Mehadia
      pathFinding.Graph.AddUndirectedEdge("Dobreta", "Mehadia", 75);

      // Eforie <-> Hirsova
      pathFinding.Graph.AddUndirectedEdge("Eforie", "Hirsova", 86);

      // Fagaras <-> Sibiu
      pathFinding.Graph.AddUndirectedEdge("Fagaras", "Sibiu", 99);

      // Hirsova <-> Urziceni
      pathFinding.Graph.AddUndirectedEdge("Hirsova", "Urziceni", 98);

      // Iasi <-> Neamt
      pathFinding.Graph.AddUndirectedEdge("Iasi", "Neamt", 87);
      // Iasi <-> Vaslui
      pathFinding.Graph.AddUndirectedEdge("Iasi", "Vaslui", 92);

      // Lugoj <-> Mehadia
      pathFinding.Graph.AddUndirectedEdge("Lugoj", "Mehadia", 70);
      // Lugoj <-> Timisoara
      pathFinding.Graph.AddUndirectedEdge("Lugoj", "Timisoara", 111);

      // Oradea <-> Zerind
      pathFinding.Graph.AddUndirectedEdge("Oradea", "Zerind", 71);
      // Oradea <-> Sibiu
      pathFinding.Graph.AddUndirectedEdge("Oradea", "Sibiu", 151);

      // Pitesti <-> Rimnicu Vilcea
      pathFinding.Graph.AddUndirectedEdge("Pitesti", "Rimnicu Vilcea", 97);

      // Rimnicu Vilcea <-> Sibiu
      pathFinding.Graph.AddUndirectedEdge("Rimnicu Vilcea", "Sibiu", 80);

      // Urziceni <-> Vaslui
      pathFinding.Graph.AddUndirectedEdge("Urziceni", "Vaslui", 142);

      start = pathFinding.Graph.Nodes["Oradea"];

      end = pathFinding.Graph.Nodes["Neamt"];

      Console.WriteLine("\nBreadth First Search algorithm");

      Pathfinding.BreadthFirstSearch(start, end);

      foreach(Node n in pathFinding.Graph.Nodes)
        n.Data = null;

      Console.WriteLine("\n\nDepth First Search algorithm");

      Pathfinding.DepthFirstSearch(start, end);

      Console.WriteLine("\n\nShortest path");

      Pathfinding.ShortestPath(start, end);

      pathFinding.Graph.Clear();

      Console.ReadKey();
    }
  }

  class Pathfinding
  {
    private static Graph graph = new Graph();

    private static Hashtable dist = new Hashtable();
    private static Hashtable route = new Hashtable();

    /// <summary>
    /// Performs a Breadth Search search
    /// </summary>
    /// <param name="start"></param>
    /// <param name="end"></param>
    public static void BreadthFirstSearch(Node start, Node end)
    {
      Queue<Node> queue = new Queue<Node>();

      queue.Enqueue(start);

      while(queue.Count != 0)
      {
        Node u = queue.Dequeue();

        // Check if node is the end
        if(u == end)
        {
          Console.Write("Path found.");

          break;
        }
        else
        {
          u.Data = "Visited";

          // Expands u's neighbors in the queue
          foreach(EdgeToNeighbor edge in u.Neighbors)
          {
            if(edge.Neighbor.Data == null)
            {
              edge.Neighbor.Data = "Visited";

              if(edge.Neighbor != end)
              {
                edge.Neighbor.PathParent = u;

                PrintPath(edge.Neighbor);
              }
              else
              {
                edge.Neighbor.PathParent = u;

                PrintPath(edge.Neighbor);

                return;
              }

              Console.WriteLine();
            }
            /* shows the repeated nodes
            else
            {
              Console.Write(edge.Neighbor.Key);
            } */

            queue.Enqueue(edge.Neighbor);
          }
        }
      }
    }

    /// <summary>
    /// Performs a Depth First search
    /// </summary>
    /// <param name="start"></param>
    /// <param name="end"></param>
    public static void DepthFirstSearch(Node start, Node end)
    {
      Stack<Node> stack = new Stack<Node>();

      stack.Push(start);

      while(stack.Count != 0)
      {
        Node u = stack.Pop();

        // Check if node is the end
        if(u == end)
        {
          Console.WriteLine("Path found");

          break;
        }
        else
        {
          u.Data = "Visited";

          // Store n's neighbors in the stack
          foreach(EdgeToNeighbor edge in u.Neighbors)
          {
            if(edge.Neighbor.Data == null)
            {
              edge.Neighbor.Data = "Visited";

              if(edge.Neighbor != end)
              {
                edge.Neighbor.PathParent = u;

                PrintPath(edge.Neighbor);
              }
              else
              {
                edge.Neighbor.PathParent = u;

                PrintPath(edge.Neighbor);

                return;
              }

              Console.WriteLine();

              stack.Push(edge.Neighbor);
            }
            /* shows the repeated nodes
            else
            {
              Console.Write(edge.Neighbor.Key);
            } */
          }
        }
      }
    }

    /// <summary>
    /// Initializes the distance and route tables used for Dijkstra's Algorithm.
    /// </summary>
    /// <param name="start">The <b>Key</b> to the source Node.</param>
    static void InitDistRouteTables(string start)
    {
      // set the initial distance and route for each city in the pathFinding.Graph
      foreach(Node n in graph.Nodes)
      {
        dist.Add(n.Key, Int32.MaxValue);
        route.Add(n.Key, null);
      }

      // set the initial distance of start to 0
      dist[start] = 0;
    }

    /// <summary>
    /// Relaxes the edge from the Node uCity to vCity.
    /// </summary>
    /// <param name="cost">The distance between uCity and vCity.</param>
    private static void Relax(Node uCity, Node vCity, int cost)
    {
      int distTouCity = (int)dist[uCity.Key];
      int distTovCity = (int)dist[vCity.Key];

      if(distTovCity > distTouCity + cost)
      {
        // update distance and route
        dist[vCity.Key] = distTouCity + cost;
        route[vCity.Key] = uCity;
      }
    }

    /// <summary>
    /// Retrieves the Node from the passed-in NodeList that has the <i>smallest</i> value in the distance table.
    /// </summary>
    /// <remarks>This method of grabbing the smallest Node gives Dijkstra's Algorithm a running time of
    /// O(<i>n</i><sup>2</sup>), where <i>n</i> is the number of nodes in the pathFinding.Graph.  A better approach is to
    /// use a <i>priority queue</i> data structure to store the nodes, rather than an array.  Using a priority queue
    /// will improve Dijkstra's running time to O(E lg <i>n</i>), where E is the number of edges.  This approach is
    /// preferred for sparse pathFinding.Graphs.  For more information on this, consult the README included in the download.</remarks>
    private static Node GetMin(NodeList nodes)
    {
      // find the node in nodes with the smallest distance value
      int minDist = Int32.MaxValue;
      Node minNode = null;
      foreach(Node n in nodes)
      {
        if(((int)dist[n.Key]) <= minDist)
        {
          minDist = (int)dist[n.Key];
          minNode = n;
        }
      }

      return minNode;
    }

    /// <summary>
    /// Dijkstra's Algorithm to find the shortest path.
    /// </summary>
    static public void ShortestPath(Node start, Node end)
    {
      if(start == end)
      {
        Console.WriteLine("There's no shortest path: start and end city are equal.");

        return;
      }
       
      InitDistRouteTables(start.Key);		// initialize the route & distance tables

      NodeList nodes = graph.Nodes;	// nodes == Q

      /**** START DIJKSTRA ****/
      while(nodes.Count > 0)
      {
        Node u = GetMin(nodes);		// get the minimum node
        nodes.Remove(u);			// remove it from the set Q

        // iterate through all of u's neighbors
        foreach(EdgeToNeighbor edge in u.Neighbors)
          Relax(u, edge.Neighbor, edge.Cost);		// relax each edge
      }	// repeat until Q is empty
      /**** END DIJKSTRA ****/

      // Display results
      string results = "The shortest path from " + start.Key + " to " + end.Key + " is " + dist[end.Key].ToString() + " miles and goes as follows: ";

      Stack traceBackSteps = new Stack();

      Node current = new Node(end.Key, null);

      Node prev = null;

      do
      {
        prev = current;
        current = (Node)route[current.Key];

        string temp = current.Key + " to " + prev.Key + "\r\n";
        traceBackSteps.Push(temp);
      } while(current.Key != start.Key);

      StringBuilder sb = new StringBuilder(30 * traceBackSteps.Count);
      while(traceBackSteps.Count > 0)
        sb.Append((string)traceBackSteps.Pop());

      Console.WriteLine(results + "\r\n\r\n" + sb.ToString());

      dist.Clear();
      route.Clear();
    }

    /// <summary>
    /// Prints the graph's edges
    /// </summary>
    static public void ShowEdges()
    {
      foreach(Node node in graph.Nodes)
        foreach(EdgeToNeighbor edge in node.Neighbors)
          Console.WriteLine("{0} <-> {1} - {2} miles", node.Key, edge.Neighbor.Key, edge.Cost);
    }

    /// <summary>
    /// Prints the full path for each search iteration
    /// </summary>
    /// <param name="node"></param>
    static public void PrintPath(Node node)
    {
      if(node.PathParent != null)
        PrintPath(node.PathParent);

      Console.Write("{0} ", node.Key);
    }

    public virtual Graph Graph
    {
      get
      {
        return graph;
      }
      set
      {
        graph = value;
      }
    }

  }

}