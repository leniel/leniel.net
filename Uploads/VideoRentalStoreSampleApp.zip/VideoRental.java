import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VideoRental extends JDialog
{ 
  // Class attributes
  private JLabel      labelClient          = new JLabel("Client code:");
  private JLabel      labelClientName      = new JLabel("[ Client name ]");
  private JTextField  textFieldClientCode  = new JTextField("");
  private JLabel      labelVideo           = new JLabel("Video Code:");
  private JLabel      labelVideoName       = new JLabel("[ Video name ]");
  private JTextField  textFieldVideoCode   = new JTextField("");
  private JLabel      labelPressTab1       = new JLabel("Press <TAB>");
  private JLabel      labelPressTab2       = new JLabel("after typing the video code");
  private JButton     btnRent              = new JButton("Rent");
  private JButton     btnClear             = new JButton("Clear");
  private boolean     clientExists         = false;
  private boolean     movieExists          = false;
  
  public VideoRental()
  {
    // Window layout definition
    this.getContentPane().setLayout(null);
    this.setSize(420, 132);
    this.setTitle("Video Rental");
    this.setResizable(false);
    this.setModal(true);
      
    labelClient.setBounds(new Rectangle(10, 15, 100, 13));
    this.getContentPane().add(labelClient, null);

    labelClientName.setBounds(new Rectangle(188, 14, 230, 13));
    this.getContentPane().add(labelClientName, null);

    textFieldClientCode.setBounds(new Rectangle(82, 12, 100, 21));
    this.getContentPane().add(textFieldClientCode, null);

    labelVideo.setBounds(new Rectangle(10, 41, 100, 13));
    this.getContentPane().add(labelVideo, null);

    btnRent.setBounds(new Rectangle(304, 70, 100, 30));
    this.getContentPane().add(btnRent, null);

    textFieldVideoCode.setBounds(new Rectangle(82, 36, 100, 21));
    this.getContentPane().add(textFieldVideoCode, null);

    labelVideoName.setBounds(new Rectangle(188, 39, 230, 13));
    this.getContentPane().add(labelVideoName, null);

    labelPressTab1.setBounds(new Rectangle(18, 65, 200, 13));
    this.getContentPane().add(labelPressTab1, null);

    labelPressTab2.setBounds(new Rectangle(18, 83, 200, 13));
    this.getContentPane().add(labelPressTab2, null);

    btnClear.setBounds(new Rectangle(200, 70, 100, 30));
    this.getContentPane().add(btnClear, null);

    // JTextField textFieldClientCode event
    textFieldClientCode.addFocusListener (new FocusAdapter()
    {
      public void focusLost(FocusEvent e)
      {
        textFieldClientCodeOnExit();
      }
    });

    // JButton btnRent event
    btnRent.addActionListener (new ActionListener()
    { public void actionPerformed(ActionEvent e)
      {
        rentButtonAction();
      }
    });

    // JTextField textFieldVideoCode event
    textFieldVideoCode.addFocusListener (new FocusAdapter()
    { 
      public void focusLost(FocusEvent e)
      {
        textFieldVideoCodeOnExit();
      }
    });

    // JButton btnClear event
    btnClear.addActionListener (new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        clearButtonAction();
      }
    });

    // Window close button event
    this.addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent e)
      {
        onExit();
      }
    });
  }

  // Called methods

  // JTextField textFieldClientCode event
  private void textFieldClientCodeOnExit()
  {
    DatabaseAccess ac = new DatabaseAccess();
    
    if(ac.connect())
    {
      clientExists = (ac.checkExist("CLIENT where (CLIENT_CODE = '"
                   + textFieldClientCode.getText() + "')") > 0);
      
      textFieldClientCode.setEnabled(((clientExists) ? false : true));
      
      if(clientExists)
      { // Search rest
        String[] rCampos = new String[1];
        
        ac.retFields(rCampos, "CLIENT_NAME", 
                     "CLIENT where (CLIENT_CODE = '"
                     + textFieldClientCode.getText() + "')");
        
        labelClientName.setText(rCampos[0]);
      }
      else
        labelClientName.setText("Client does not exist.");
      
       
      ac.disconnect();
    }
      
    btnRent.setEnabled(((clientExists) && (movieExists)));  
  }

  // JTextField textFieldVideoCode exit event
  private void textFieldVideoCodeOnExit()
  {
    DatabaseAccess ac = new DatabaseAccess();
    
    if(ac.connect())
    {
      movieExists = (ac.checkExist("VIDEO where (VIDEO_CODE = '"
                             + textFieldVideoCode.getText()
                             + "') and (VIDEO_SITUATION = 'F')") > 0);
      
      textFieldVideoCode.setEnabled(((movieExists) ? false : true));
      
      if(movieExists)
      { // Search the rest
        String[] rCampos = new String[1];
        
        ac.retFields(rCampos, "VIDEO_NAME", 
                     "VIDEO where (VIDEO_CODE = '"
                     + textFieldVideoCode.getText() + "')");
        
        labelVideoName.setText(rCampos[0]);
      }
      else
         labelVideoName.setText("Video isn't available.");

      ac.disconnect();
    }
    
    btnRent.setEnabled(((clientExists) && (movieExists)));  
  }
  
  // Button Clear
  private void clearButtonAction()
  {
    btnRent.setEnabled(false);
    clientExists = false;
    movieExists = false;
    textFieldClientCode.setEnabled(true);
    textFieldVideoCode.setEnabled(true);
    textFieldClientCode.setText("");
    textFieldVideoCode.setText("");
    labelClientName.setText("");
    labelVideoName.setText("");
    textFieldClientCode.requestFocus();
  }

  // Button Rent
  private void rentButtonAction()
  {
    DatabaseAccess ac = new DatabaseAccess();
    
    if(ac.connect())
    {
      ac.executeSQL("insert into RENTAL (CLIENT_CODE, VIDEO_CODE) "
                 + "values ('" + textFieldClientCode.getText() + "', '"
                 + textFieldVideoCode.getText() + "')");
      
      ac.executeSQL("update VIDEO set VIDEO_SITUATION = 'R' "
                 + " where VIDEO_CODE ='" + textFieldVideoCode.getText() + "'");
      
      ac.disconnect();
      
      btnRent.setEnabled(false);
      movieExists = false;
      labelVideoName.setText("");
      textFieldVideoCode.setText("");
      textFieldVideoCode.setEnabled(true);
      textFieldVideoCode.requestFocus();
    }
  }

  // Window close button
  private void onExit()
  {
    dispose();
  }

}