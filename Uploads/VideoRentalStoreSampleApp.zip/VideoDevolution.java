import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VideoDevolution extends JDialog
{
  // Class attributes definition
  private JLabel       labelClient       = new JLabel("Client:");
  private JLabel       labelRentedVideo  = new JLabel("Rented Video(s)");
  private JComboBox    clientsComboBox   = new JComboBox();
  private JList        videoList         = new JList();
  private JScrollPane  jScrollPane1      = new JScrollPane();
  private JButton      btnReturn         = new JButton("Return");

  // Class constructor
  public VideoDevolution()
  {
    loadClientsComboBox();
    
    setVideo();
    
    this.getContentPane().setLayout(null);
    this.setSize(292, 316);
    this.setTitle("Video Devolution");
    this.setResizable(false);
    this.setModal(true);

    labelClient.setBounds(new Rectangle(9, 21, 57, 13));
    this.getContentPane().add(labelClient, null);

    labelRentedVideo.setBounds(new Rectangle(17, 58, 100, 13));
    this.getContentPane().add(labelRentedVideo, null);

    clientsComboBox.setBounds(new Rectangle(75, 16, 200, 21));
    this.getContentPane().add(clientsComboBox, null);

    jScrollPane1.setBounds(new Rectangle(15, 78, 260, 160));
    jScrollPane1.getViewport().add(videoList, null);
    this.getContentPane().add(jScrollPane1, null);

    btnReturn.setBounds(new Rectangle(175, 247, 100, 30));
    this.getContentPane().add(btnReturn, null);

    // JButton btnReturn event
    btnReturn.addActionListener (new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        returnButtonAction();
      }
    });

    // JComboBox clientsComboBox
    clientsComboBox.addActionListener (new ActionListener()
    { public void actionPerformed(ActionEvent e)
      {
        setVideo();
      }
    });

    // Window close button event
    this.addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent e)
      {
        onClosing();
      }
    });
  }

  // Other class methods (called by the constructor)

  // Load the Clients combo box
  private void loadClientsComboBox()
  {
    DatabaseAccess ac = new DatabaseAccess();
    
    if(ac.connect())
    {
      ac.loadComboBox(clientsComboBox, "c.CLIENT_NAME", "CLIENT c inner join RENTAL r "
                   + " on c.CLIENT_CODE = r.CLIENT_CODE " + "group by CLIENT_NAME");
      
      ac.disconnect();
   }
  }

  // Loads the video list
  private void setVideo()
  {
    DatabaseAccess access = new DatabaseAccess();
    
    if (access.connect())
    {
      access.loadList(videoList, "v.VIDEO_NAME", "(CLIENT as c inner join " + "RENTAL as r on c.CLIENT_CODE = " +
                   "r.CLIENT_CODE) inner join VIDEO v " + "on r.VIDEO_CODE = v.VIDEO_CODE " +
                   "where c.CLIENT_NAME = '" + clientsComboBox.getSelectedItem() + "'");
      
      access.disconnect();
    }
  }


  // Performs the video devolution for the selected client
  private void returnButtonAction()
  {
    DatabaseAccess access = new DatabaseAccess();
    
    if(access.connect())
    {
      String clientCode = access.returnCode("CLIENT_CODE from CLIENT " + "where CLIENT_NAME = '"
                                        + clientsComboBox.getSelectedItem() + "'");
      
      String videoCode = access.returnCode("VIDEO_CODE from VIDEO " + "where (VIDEO_NAME = '"
             + videoList.getSelectedValue() + "')");
        
      access.executeSQL("update VIDEO set VIDEO_SITUATION = 'F' " + "where (VIDEO_CODE = '" + videoCode + "')");
      access.executeSQL("delete from RENTAL " + "Where (CLIENT_CODE = '" + clientCode + "') " +
                                                    "and (VIDEO_CODE = '" + videoCode + "')");
      
      access.disconnect();
    }
    
    loadClientsComboBox();
  }  

  private void onClosing()
  {
    dispose();
  }
}