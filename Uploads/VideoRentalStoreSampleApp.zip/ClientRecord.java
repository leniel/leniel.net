import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ClientRecord extends JDialog
{
  // Defining the class attributes
  private JLabel     labelClientCode      = new JLabel("Code:");
  private JLabel     labelClientName      = new JLabel("Name:");
  private JTextField textFieldClientCode  = new JTextField("");
  private JTextField textFieldClientName  = new JTextField("");
  private JButton    btnSave              = new JButton("Save");
  private JButton    btnDelete            = new JButton("Delete");
  private JButton    btnClear             = new JButton("Clear");
  private boolean    flag;
  
  // Class methods definition
  // Class constructor method
  public ClientRecord()
  {
    // Window layout definitions
    this.getContentPane().setLayout(null);
    this.setSize(409, 148);
    this.setTitle("Client Record");
    this.setResizable(false);
    this.setModal(true);
    
    labelClientCode.setBounds(new Rectangle(35, 17, 57, 13));
    this.getContentPane().add(labelClientCode, null);
    
    labelClientName.setBounds(new Rectangle(42, 48, 50, 13));
    this.getContentPane().add(labelClientName, null);
    
    textFieldClientCode.setBounds(new Rectangle(92, 14, 100, 21));
    this.getContentPane().add(textFieldClientCode, null);
    
    textFieldClientName.setBounds(new Rectangle(92, 45, 300, 21));
    this.getContentPane().add(textFieldClientName, null);
    
    btnSave.setBounds(new Rectangle(10, 86, 100, 30));
    this.getContentPane().add(btnSave, null);
    
    btnDelete.setBounds(new Rectangle(114, 86, 100, 30));
    this.getContentPane().add(btnDelete, null);
    
    btnClear.setBounds(new Rectangle(218, 86, 100, 30));
    this.getContentPane().add(btnClear, null);
    
    // JTextField textFieldClientCode event
    textFieldClientCode.addFocusListener(new FocusAdapter()
    {
      public void focusLost(FocusEvent e)
      {
        textFieldClientCodeExit(); // Calling the exitEdCode() method
      }
    });
    
    // JButton btnSave event
    btnSave.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        saveButtonAction(); // Calling the saveButtonAction() method
      }
    });
    
    // JButton btnDelete event
    btnDelete.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        deleteButtonAction(); //  Calling the deleteButtonAction() method
      }
    });
    
    // JButton btnClear event
    btnClear.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        clearButtonAction(); //  Calling the clearButtonAction() method
      }
    });
    
    // JButton btnClose event
    this.addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent e)
      {
        closeButtonAction(); // Calling the closeButtonAction() method
      }
    });
  } // End ClientRecord() constructor
  
  // Other class methods called by the constructor
  
  // Exit JTextField textFieldClientCode
  private void textFieldClientCodeExit()
  {
    DatabaseAccess access = new DatabaseAccess();
    
    if(access.connect())
    {
      flag = (access.checkExist("CLIENT where (CLIENT_CODE = '" + textFieldClientCode.getText()
      + "')") > 0);
      
      textFieldClientCode.setEnabled(((flag) ? false : true));
      
      if(flag)
      {
        // Continue searching
        String[] rFields = new String[1];
        
        access.retFields(rFields, "CLIENT_NAME", "CLIENT where (CLIENT_CODE = '"
                + textFieldClientCode.getText() + "')");
        
        textFieldClientName.setText(rFields[0]);
      }
      
      access.disconnect();
    }
  }
  // End textFieldClientCodeExit()
  
  // Save button
  private void saveButtonAction()
  {
    DatabaseAccess access = new DatabaseAccess();
    
    if(access.connect())
    {
      if(flag)
      {
        access.executeSQL("update CLIENT set " + "CLIENT_NAME = '" + textFieldClientName.getText()
        + "'" + "where (CLIENT_CODE = '" + textFieldClientCode.getText() + "')");
      }
      else
      {
        access.executeSQL("insert into CLIENT (CLIENT_CODE, CLIENT_NAME)"
                + "values ('" + textFieldClientCode.getText() + "','" + textFieldClientName.getText()
                + "')");
      }
      
      access.disconnect();
      
      clearButtonAction();
    }
  }
  // End saveButtonAction()
  
  // Delete button
  private void deleteButtonAction()
  {
    if(flag)
    {
      DatabaseAccess access = new DatabaseAccess();
      
      if(access.connect())
      {
        access.executeSQL("delete from CLIENT " + "where (CLIENT_CODE = '"
                + textFieldClientCode.getText() + "')");
        access.disconnect();
        
        clearButtonAction();
      }
    }
  }
  // End deleteButtonAction()
  
  // Clear button
  private void clearButtonAction()
  {
    textFieldClientCode.setText("");
    textFieldClientName.setText("");
    textFieldClientCode.setEnabled(true);
    textFieldClientCode.requestFocus();
  }
  // End clearButtonAction()
  
  // Close Windows button
  private void closeButtonAction()
  {
    dispose();
  }
  // End closeButtonAction()
  
} // End ClientRecord.java
