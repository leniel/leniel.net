import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VideoRecord extends JDialog
{
  // Class attributes
  private JLabel labelCode = new JLabel("Code:");
  private JLabel labelName = new JLabel("Name:");
  private JTextField textFieldVideoCode = new JTextField("");
  private JTextField textFieldVideoName = new JTextField("");
  private JButton btnSave = new JButton("Save");
  private JButton btnDelete = new JButton("Delete");
  private JButton btnClear = new JButton("Clear");
  private boolean flag;
  
  // Class methods
  // Class constructor
  public VideoRecord()
  {
    // Window layout definition
    this.getContentPane().setLayout(null);
    this.setSize(409, 182);
    this.setTitle("Video Record");
    this.setResizable(false);
    this.setModal(true);

    labelCode.setBounds(new Rectangle(35, 17, 57, 13));
    this.getContentPane().add(labelCode, null);

    labelName.setBounds(new Rectangle(42, 48, 50, 13));
    this.getContentPane().add(labelName, null);

    textFieldVideoCode.setBounds(new Rectangle(92, 14, 100, 21));
    this.getContentPane().add(textFieldVideoCode, null);

    textFieldVideoName.setBounds(new Rectangle(92, 45, 300, 21));
    this.getContentPane().add(textFieldVideoName, null);

    btnSave.setBounds(new Rectangle(10, 120, 100, 30));
    this.getContentPane().add(btnSave, null);

    btnDelete.setBounds(new Rectangle(114, 120, 100, 30));
    this.getContentPane().add(btnDelete, null);

    btnClear.setBounds(new Rectangle(218, 120, 100, 30));
    this.getContentPane().add(btnClear, null);

    // JTextField textFieldVideoCode event
    textFieldVideoCode.addFocusListener(new FocusAdapter()
    {
      public void focusLost(FocusEvent e)
      {
        ExitEdCode();
      }
    });

    // JButton btnSave
    btnSave.addActionListener (new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        actionBtnSave();
      }
    });

    // Evento sobre o JButton btExcluir
    btnDelete.addActionListener (new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        actionBtnDelete();
      }
    });

    // Evento sobre o JButton btLimpar
    btnClear.addActionListener (new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        actionBtnClear();
      }
    });

    // Window close button event
    this.addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent e)
      {
        OnClosing();
      }
    });
  }

  // Other class methods(called by the constructor)

  // JTextField edCodigo OnExit
  private void ExitEdCode()
  {
    DatabaseAccess ac = new DatabaseAccess();
    
    if(ac.connect()) 
    {
      flag = (ac.checkExist("VIDEO where (VIDEO_CODE = '" + textFieldVideoCode.getText()
                + "')") > 0);
      textFieldVideoCode.setEnabled(((flag) ? false : true));

      if(flag)
      { 
        // Search rest
        String[] rCampos = new String[1];
        
        ac.retFields(rCampos, "VIDEO_NAME", "VIDEO where (VIDEO_CODE = '"
                     + textFieldVideoCode.getText() + "')");
        
        textFieldVideoName.setText(rCampos[0]);
      }
      
      ac.disconnect();
    }
  }

  // Button Save
  private void actionBtnSave()
  {
    DatabaseAccess ac = new DatabaseAccess();
    
    if(ac.connect())
    {
      if(flag)
      {
        ac.executeSQL("update VIDEO set " + "VIDEO_NAME = '" + textFieldVideoName.getText() + "'"
                   + "where (VIDEO_CODE = '" + textFieldVideoCode.getText() + "')");
      }
      else
      {
        ac.executeSQL("insert into VIDEO (VIDEO_CODE, VIDEO_NAME, VIDEO_SITUATION) "
                   + "values ('" + textFieldVideoCode.getText() + "','" + textFieldVideoName.getText()
                   + "','F'" + ")");
      }
      
      ac.disconnect();
      
      actionBtnClear();
    }
  }

  // Button Delete
  private void actionBtnDelete()
  {
    if(flag)
    {
      DatabaseAccess ac = new DatabaseAccess();
      
      if(ac.connect())
      {
        ac.executeSQL("delete from VIDEO " + "where (VIDEO_CODE = '" 
                    + textFieldVideoCode.getText() + "')");
        
        ac.disconnect();
        
        actionBtnClear();
      }
    }
  }

  // Button Clear
  private void actionBtnClear()
  {
    textFieldVideoCode.setText("");
        
    textFieldVideoName.setText("");
    
    textFieldVideoCode.setEnabled(true);
    
    textFieldVideoCode.requestFocus();
  }

  // Window Close Button
  private void OnClosing()
  {
    dispose();
  }
}
