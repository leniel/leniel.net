import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * Implements a simple menu.
 */
public class MainMenu extends JFrame
{ 
  // Class's constructor
  public MainMenu()
  { 
    // Defining the behaviour of the main window
    this.getContentPane().setLayout(null);
    
    this.setTitle("Video Rental Store");
    
    this.setSize(500, 350);
    
    this.setVisible(true);

    this.addWindowListener(new WindowAdapter() // Enabling the close button
    {
      public void windowClosing(WindowEvent e)
      {
        onClosing(e);
      }
    });

    // Class attributes
    JMenuBar menu = new JMenuBar();
    
    JMenu file = new JMenu("File");
    
    JMenu record = new JMenu("Records");
    JMenuItem video = new JMenuItem("Video");
    JMenuItem client = new JMenuItem("Client");
    
    JMenuItem exit = new JMenuItem("Exit");

    JMenu billing = new JMenu("Billing");
    JMenuItem rental = new JMenuItem("Rental");
    JMenuItem devolution = new JMenuItem("Devolution");

    // Defining the mnemonics
    file.setMnemonic('F');
    record.setMnemonic('R');
    video.setMnemonic('V');
    client.setMnemonic('C');
    exit.setMnemonic('E');
    billing.setMnemonic('B');
    rental.setMnemonic('R');
    devolution.setMnemonic('D');

    // Mouting the MainMenu
    menu.add(file);
    
    file.add(record);
    record.add(client);
    record.add(video);
    
    file.addSeparator();
    
    file.add(exit);
    
    menu.add(billing);
    billing.add(rental);
    billing.add(devolution);
   
    // Adding the MainMenu bar
    this.setJMenuBar(menu);  

    // Defining the MainMenu method callings
    video.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        optVideoRecording();
      }
    });

    client.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        optClientRecording();
      }
    });

    rental.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        optVideoRental();
      }
    });

    devolution.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        optVideoDevolution();
      }
    });

    exit.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        optExit();
      }
    });
   }

   // More class methods (called by the constructor)

   // Method that calls the VideoRecord's management
   private void optVideoRecording()
   {
     VideoRecord window = new VideoRecord();
     
     window.show();
   }

   // Method that calls the ClientRecord recording
   private void optClientRecording()
   {
     ClientRecord window = new ClientRecord();
     
     window.show();
   }

   // Method that calls the VideoRecord Rental window
   private void optVideoRental()
   {
     VideoRental window = new VideoRental();
     
     window.show();
   }

   // Method that calls the VideoRecord Devolution window
   private void optVideoDevolution()
   {
     VideoDevolution window = new VideoDevolution();
     
     window.show();
   }

   // Method that closes the Window through the option Exit from the MainMenu
   private void optExit()
   {
     System.exit(0);
   }

   // Method that closes the Window through the close button
   private void onClosing(WindowEvent e)
   {
     System.exit(0);
   }

   public static void main(String[] args)
   {
     MainMenu menu = new MainMenu();
     
     menu.show();
   }

}