ODBC

Configure the ODBC for the file VideoRentalStore.mdb located on C:\VideoRentalStoreSampleApp\VideoRentalStore.mdb.


Java

1 - Work inside:        C:\VideoRentalStoreSampleApp

2 - To compile the app: javac MainMenu.java

3 - To run the app:     java MainMenu