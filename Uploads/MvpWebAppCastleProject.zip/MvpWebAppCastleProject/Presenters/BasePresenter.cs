﻿using System;
using MvpWebAppCastleProject.Interfaces;

namespace MvpWebAppCastleProject.Presenters
{
    /// <summary>
    /// Base Presenter Typed
    /// All the Presenters should inherit from this one and implement the methods
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class BasePresenter<V>
        where V : IBaseView
    {
        /// <summary>
        /// Typed View
        /// </summary>
        protected static V view;

        protected BasePresenter()
        {

        }

        /// <summary>
        /// Registers the View to the Presenter
        /// </summary>
        /// <param name="myView">View type</param>
        public void RegisterView(V myView)
        {
            if(myView == null)
            {
                throw new ArgumentNullException("View cannot be null.");
            }

            view = myView;

            SubscribePresenterToViewEvents();
        }

        /// <summary>
        /// Subscribe the Presenter to View events
        /// </summary>
        protected abstract void SubscribePresenterToViewEvents();

        /// <summary>
        /// Specific FirstLoading implemented by each inheritor
        /// </summary>
        protected abstract void FirstLoading();

        /// <summary>
        /// Run when the page is loaded for the first time
        /// </summary>
        protected void FirstLoading(object source, EventArgs eventArgs)
        {
            FirstLoading();
        }
    }
}
