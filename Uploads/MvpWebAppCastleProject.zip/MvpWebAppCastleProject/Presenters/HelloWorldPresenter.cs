﻿using MvpWebAppCastleProject.Interfaces;

namespace MvpWebAppCastleProject.Presenters
{
    public class HelloWorldPresenter : BasePresenter<IHelloWorldView>
    {
        public HelloWorldPresenter()
        {

        }

        #region Overrides of BasePresenter<IHellowWorldView>

        /// <summary>
        /// Subscribe the Presenter to View events
        /// </summary>
        protected override void SubscribePresenterToViewEvents()
        {
            view.FirstLoading += FirstLoading;
        }

        /// <summary>
        /// Specific FirstLoading implemented by each inheritor
        /// </summary>
        protected override void FirstLoading()
        {
            view.HelloWorld();
        }

        #endregion
    }
}
