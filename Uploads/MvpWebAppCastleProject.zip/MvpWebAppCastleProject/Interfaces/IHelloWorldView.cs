﻿using System;

namespace MvpWebAppCastleProject.Interfaces
{
    public interface IHelloWorldView : IBaseView
    {
        event EventHandler FirstLoading;

        void HelloWorld();
    }
}
