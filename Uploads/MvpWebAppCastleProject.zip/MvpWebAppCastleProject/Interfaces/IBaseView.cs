﻿namespace MvpWebAppCastleProject.Interfaces
{
    public interface IBaseView
    {

    }
}
