﻿using System;
using System.Web.UI;
using MvpWebAppCastleProject.Interfaces;
using MvpWebAppCastleProject.Presenters;

namespace MvpWebAppCastleProject.Views
{
    public partial class HelloWorldView : Page, IHelloWorldView
    {
        private HelloWorldPresenter presenter;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Inversion of Control
            presenter = IoC.Resolve<HelloWorldPresenter>();
            presenter.RegisterView(this);

            if(!IsPostBack)
            {
                if(FirstLoading != null)
                {
                    FirstLoading(this, EventArgs.Empty);
                }
            }
        }

        #region Implementation of IHelloWorldView

        public event EventHandler FirstLoading;

        public void HelloWorld()
        {
            Response.Write("Hello World from ASP.NET Web App that implements the MVP pattern!");
        }

        #endregion
    }
}
