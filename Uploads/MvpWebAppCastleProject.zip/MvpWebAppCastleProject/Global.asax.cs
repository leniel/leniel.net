﻿using System;
using System.Web;

namespace MvpWebAppCastleProject
{
    public class Global : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            IoC.Initialize(new BusinessContainer());
        }
    }
}