using System;
using System.IO;
using System.Web.Mvc;
using NPOI.HSSF.UserModel;

namespace ExcelWriterMvcProject.Controllers
{
    public class ExcelWriterController : Controller
    {
        /// <summary>
        /// Creates a new Excel spreadsheet based on a template using the NPOI library.
        /// The template is changed in memory and a copy of it is sent to
        /// the user computer through a file stream.
        /// </summary>
        /// <returns>Excel report</returns>
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult NPOICreate()
        {
            try
            {
                // Opening the Excel template...
                FileStream fs =
                    new FileStream(Server.MapPath(@"\Content\NPOITemplate.xls"), FileMode.Open, FileAccess.Read);

                // Getting the complete workbook...
                HSSFWorkbook templateWorkbook = new HSSFWorkbook(fs, true);

                // Getting the worksheet by its name...
                HSSFSheet sheet = templateWorkbook.GetSheet("Sheet1");

                HSSFRow row7 = sheet.CreateRow(6);

                row7.CreateCell(1).SetCellValue("David killed Goliath");
                row7.CreateCell(2).SetCellValue(7);
                row7.CreateCell(3).SetCellValue(7);
                row7.CreateCell(4).SetCellValue(7);
                row7.CreateCell(5).SetCellValue(7);

                HSSFRow row8 = sheet.CreateRow(7);

                row8.CreateCell(1).SetCellValue("Moses of Egypt");
                row8.CreateCell(2).SetCellValue(8);
                row8.CreateCell(3).SetCellValue(8);
                row8.CreateCell(4).SetCellValue(8);
                row8.CreateCell(5).SetCellValue(8);

                HSSFRow row9 = sheet.CreateRow(8);

                row9.CreateCell(1).SetCellValue("David Shepherd");
                row9.CreateCell(2).SetCellValue(9);
                row9.CreateCell(3).SetCellValue(9);
                row9.CreateCell(4).SetCellValue(9);
                row9.CreateCell(5).SetCellValue(9);

                HSSFRow row10 = sheet.CreateRow(9);

                row10.CreateCell(1).SetCellValue("Jesus of Nazareth");
                row10.CreateCell(2).SetCellValue(10);
                row10.CreateCell(3).SetCellValue(10);
                row10.CreateCell(4).SetCellValue(10);
                row10.CreateCell(5).SetCellValue(10);

                sheet.ForceFormulaRecalculation = true;

                MemoryStream ms = new MemoryStream();

                // Writing the workbook content to the FileStream...
                templateWorkbook.Write(ms);

                TempData["Message"] = "Excel report created successfully!";

                // Sending the server processed data back to the user computer...
                return File(ms.ToArray(), "application/vnd.ms-excel", "NPOINewFile.xls");
            }
            catch(Exception ex)
            {
                TempData["Message"] = "Oops! Something went wrong.";

                return RedirectToAction("NPOI");
            }
        }

        public ActionResult NPOI()
        {
            return View();
        }

    }
}
