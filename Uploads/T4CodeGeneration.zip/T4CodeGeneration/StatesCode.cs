﻿using System;
using System.Collections.Generic;

namespace T4CodeGeneration
{
    partial class States
    {
        private readonly List<Tuple<string, string>> states;

        public States(List<Tuple<string, string>> states)
        {
            this.states = states;
        }
    }
}

