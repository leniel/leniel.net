﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.VisualBasic.FileIO;

namespace T4CodeGeneration
{
    class Program
    {
        static void Main(string[] args)
        {
            States code = new States(ReadData());
            String result = code.TransformText();
            File.WriteAllText("outputCode.cs", result);
        }

        public static List<Tuple<string, string>> ReadData()
        {
            List<Tuple<string, string>> states = new List<Tuple<string, string>>();

            using (var myCsvFile =
                    new TextFieldParser(@"C:\Users\Leniel\Documents\Visual Studio 2010\Projects\T4CodeGeneration\USAStates.txt"))
            {
                myCsvFile.TextFieldType = FieldType.Delimited;
                myCsvFile.SetDelimiters(",");

                while (!myCsvFile.EndOfData)
                {
                    string[] fieldArray;

                    try
                    {
                        // Reading line data 
                        fieldArray = myCsvFile.ReadFields();
                    }
                    catch (MalformedLineException)
                    {
                        // Not a valid delimited line - log, terminate, or ignore
                        continue;
                    }

                    // Process values in fieldArray
                    states.Add(new Tuple<string, string>(fieldArray[0], fieldArray[1]));
                }
            }

            return states;
        }
    }
}
