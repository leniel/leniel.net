//
//  Object Oriented Systems in C++
//  Copyright �2007 Leniel Braz de Oliveira Macaferi
//  UBM Computer Engineering - 9th term [www.ubm.br]
//
//  Homework presented to the discipline of Object Oriented Systems from the Computer
//  Engineering course at the Centro Universit�rio de Barra Mansa, as a partial
//  requirement for the evaluation of grade 2, under the supervision of Prof.
//  Gustavo Lu�s Furtado Vicente.
//
//  The source code is provided "as is" without warranties.
//
//  Turn in date: 6/19/2007
//
//  Development date: 06 - 14 and 19 - 2007
//  Topic: Homework grade 2
//
//  Program that draws in the screen by free hand with the mouse assistance.
//  The program must monitor the mouse movement, indicating its position (x, y)
//  in the upright corner of the application window, in the format (xxx, yyy).
//  Pressing the left mouse button it draws and pressing the right mouse button,
//  it wipes off.
//
//  Tips: use the events:
//	
//  WM_MOUSE, WM_LBUTTONDOWN, WM_LBUTTONUP, WM_RBUTTONDOWN, WM_RBUTTONUP and the
//  function SetPixel()
//
//  lword(lParam) has 0 x
//  hiword(lParam) has 0 Y

// Win32MouseInteractionApp.cpp : Defines the entry point for the application.

#include "stdafx.h"
#include <stdio.h>
#include "Win32MouseInteractionApp.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								      // current instance
TCHAR szTitle[MAX_LOADSTRING];				// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];	// the main window class name

// Forward declarations of functions included in this code module:
ATOM				      MyRegisterClass(HINSTANCE hInstance);
BOOL				      InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int xMouse, yMouse; // Mouse x and y position on the screen
bool flag;
char strTitle[64]; // Window title
HWND hlabel;

COLORREF newColor; // Color used to paint the screen

HDC hDC;
PAINTSTRUCT paintStruct;

int APIENTRY _tWinMain(HINSTANCE hInstance,
											 HINSTANCE hPrevInstance,
											 LPTSTR    lpCmdLine,
											 int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_WIN32MOUSEINTERACTIONAPP, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_WIN32MOUSEINTERACTIONAPP));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WIN32MOUSEINTERACTIONAPP));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_WIN32MOUSEINTERACTIONAPP);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	HWND hWnd;

	hInst = hInstance; // Store instance handle in our global variable

	hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0, 640, 480, 0, NULL, NULL, hInstance, NULL);

	hlabel = CreateWindowEx(0, "static", "", WS_CHILD, 525, 2, 100, 20, hWnd, NULL, hInstance, NULL);
    ShowWindow(hlabel, SW_SHOWNORMAL);

	if (!hWnd)
	{
		return FALSE;
	}

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND     - Process the application menu
//  WM_PAINT       - Paint the main window
//  WM_DESTROY     - Post a quit message and return
//  WM_LBUTTONDOWN - Left mouse button clicked
//  WM_RBUTTONDOWN - Right mouse button clicked
//  WM_LBUTTONUP   - Left mouse button released
//  WM_RBUTTONUP   - Right mouse button released
//  WM_MOUSEMOVE   - Controls the mouse movement
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;

	switch (message)               // Handle the messages
	{
	case WM_DESTROY:

		PostQuitMessage (0);         // Send a WM_QUIT to the message queue

		break;

	case WM_PAINT:
		// TODO: Add any drawing code here...	
		hDC = GetDC(hWnd);

		BeginPaint(hWnd, &paintStruct);

		EndPaint(hWnd, &paintStruct);

		break;

	// Left button event used to print the screen
	case WM_LBUTTONDOWN:

		flag = true;

		// Black color	 
		newColor = RGB(0, 0, 0);

		xMouse = LOWORD(lParam);

		yMouse = HIWORD(lParam);

		SetPixel(hDC, xMouse, yMouse, newColor);

		break;

	// Right button event used to erase the screen content
	case WM_RBUTTONDOWN:

		flag = true;

		// White color			 
		newColor = RGB(255, 255, 255);

		xMouse = LOWORD(lParam);

		yMouse = HIWORD(lParam);

		SetPixel(hDC, xMouse, yMouse, newColor);

		break;

	// Sets the flag to false so that we know the left mouse button was released
	case WM_LBUTTONUP:

		flag = false;

		break;

	// Sets the flag to false so that we know the right mouse button was released
	case WM_RBUTTONUP:

		flag = false;

		break;

	// Controls the mouse movement and shows its current position on the Window title
	case WM_MOUSEMOVE: 

		if(flag)
		{
			xMouse = LOWORD(lParam);

			yMouse = HIWORD(lParam);

			SetPixel(hDC, xMouse, yMouse, newColor);

			sprintf_s(strTitle, "  x=%d y=%d", xMouse, yMouse);

			SetWindowText(hWnd, strTitle);

			SetWindowText(hlabel, strTitle);
		}
		else
		{
			xMouse = LOWORD(lParam);

			yMouse = HIWORD(lParam);

			sprintf_s(strTitle, "  x=%d y=%d", xMouse, yMouse);

			SetWindowText(hWnd, strTitle);

			SetWindowText(hlabel, strTitle);
		}

		break;

	case WM_LBUTTONDBLCLK:

		MessageBox(hWnd, strTitle, "Message", MB_OK | MB_ICONINFORMATION);

		break;

	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		  case IDM_ABOUT:
			  
				DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			
				break;
		
			case IDM_EXIT:
			  
				DestroyWindow(hWnd);
			
				break;
			
			default:

			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;

	  default:  // For messages that we don't deal with

		return DefWindowProc (hWnd, message, wParam, lParam);
	}

	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}