#ifndef lint
static char yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#endif
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING (yyerrflag!=0)
#define YYPREFIX "yy"
#line 2 "sinan.yacc"
   #include <stdio.h>
   #include <stdlib.h>
#line 15 "y.tab.c"
#define PROGRAM 257
#define ID 258
#define SEMIC 259
#define DOT 260
#define VAR 261
#define COLON 262
#define INTEGER 263
#define REAL 264
#define RCONS 265
#define BOOL 266
#define OCBRA 267
#define CCBRA 268
#define IF 269
#define THEN 270
#define ELSE 271
#define WHILE 272
#define DO 273
#define READ 274
#define OPAR 275
#define CPAR 276
#define WRITE 277
#define COMMA 278
#define STRING 279
#define ATRIB 280
#define RELOP 281
#define ADDOP 282
#define MULTOP 283
#define NEGOP 284
#define CONS 285
#define TRUE 286
#define FALSE 287
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    0,    1,    1,    3,    3,    4,    5,    5,    6,    6,
    6,    2,    7,    7,    8,    8,    8,    8,    8,    8,
    9,    9,   10,   11,   12,   15,   15,   16,   16,   13,
   14,   14,   17,   17,   18,   18,   19,   19,   19,   19,
   19,   19,   19,
};
short yylen[] = {                                         2,
    6,    2,    0,    2,    1,    4,    3,    1,    1,    1,
    1,    3,    3,    1,    1,    1,    1,    1,    1,    1,
    4,    6,    4,    4,    4,    3,    1,    1,    1,    3,
    1,    3,    3,    1,    3,    1,    2,    1,    1,    3,
    1,    1,    1,
};
short yydefred[] = {                                      0,
    0,    0,    0,    0,    0,    0,    8,    0,    5,    0,
    0,    0,    4,    0,    0,    0,    0,    0,    0,    0,
   20,    0,   14,   15,   16,   17,   18,   19,    1,    9,
   10,   11,    0,    7,    0,   43,   39,    0,   38,   41,
   42,    0,    0,    0,    0,    0,    0,    0,    0,   12,
    6,   30,    0,    0,    0,    0,    0,   37,    0,    0,
   29,   28,    0,   27,   13,   40,    0,    0,    0,    0,
   23,   24,   25,    0,    0,   26,   22,
};
short yydgoto[] = {                                       2,
    6,   21,    8,    9,   10,   33,   22,   23,   24,   25,
   26,   27,   28,   62,   63,   64,   43,   44,   45,
};
short yysindex[] = {                                   -242,
 -232,    0, -243, -238, -216, -222,    0, -216,    0, -253,
 -152, -210,    0, -162, -200, -225, -255, -255, -214, -209,
    0, -254,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0, -199,    0, -255,    0,    0, -255,    0,    0,
    0, -201, -270, -211, -208, -196, -216, -258, -152,    0,
    0,    0, -202, -152, -255, -255, -255,    0, -152, -272,
    0,    0, -239,    0,    0,    0, -190, -198, -211, -208,
    0,    0,    0, -258, -152,    0,    0,
};
short yyrindex[] = {                                      0,
    0,    0,    0, -180,    0,    0,    0, -178,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0, -173, -203, -235,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0, -215, -160, -188, -219,
    0,    0,    0,    0,    0,    0,    0,
};
short yygindex[] = {                                      0,
    0,   85,    0,   84,   49,    0,    0,  -41,    0,    0,
    0,    0,    0,  -16,    0,   33,   54,   56,   57,
};
#define YYTABLESIZE 125
short yytable[] = {                                      36,
   42,   46,   36,   72,   49,   15,   37,   65,   14,   37,
   55,   56,   67,   50,    1,    4,   38,   71,   52,   38,
   61,   53,    5,   36,   15,    3,   39,   40,   41,   39,
   40,   41,   36,   77,   36,   36,   73,   36,   74,   35,
   36,    7,   36,   21,   11,   36,   36,   36,   35,   29,
   35,   35,   21,   35,   35,   34,   35,   34,   35,   51,
   47,   35,   35,   35,   34,   48,   34,   34,   54,   34,
   33,   57,   34,   66,   34,   58,   59,   34,   34,   33,
   75,   33,   33,   56,   33,   31,    3,   33,    2,   33,
   12,   13,   33,   33,   31,   60,   31,   31,   32,   31,
   30,   31,   31,   32,   31,   16,   76,   32,   68,   32,
   32,   69,   32,   70,   11,   32,   17,   32,    0,   18,
    0,   19,    0,    0,   20,
};
short yycheck[] = {                                     258,
   17,   18,  258,  276,  259,  278,  265,   49,  262,  265,
  281,  282,   54,  268,  257,  259,  275,   59,   35,  275,
  279,   38,  261,  259,  278,  258,  285,  286,  287,  285,
  286,  287,  268,   75,  270,  271,  276,  273,  278,  259,
  276,  258,  278,  259,  267,  281,  282,  283,  268,  260,
  270,  271,  268,  273,  280,  259,  276,  258,  278,  259,
  275,  281,  282,  283,  268,  275,  270,  271,  270,  273,
  259,  283,  276,  276,  278,  284,  273,  281,  282,  268,
  271,  270,  271,  282,  273,  259,  267,  276,  267,  278,
    6,    8,  281,  282,  268,   47,  270,  271,  259,  273,
  263,  264,  276,  266,  278,  258,   74,  268,   55,  270,
  271,   56,  273,   57,  267,  276,  269,  278,   -1,  272,
   -1,  274,   -1,   -1,  277,
};
#define YYFINAL 2
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 287
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"PROGRAM","ID","SEMIC","DOT",
"VAR","COLON","INTEGER","REAL","RCONS","BOOL","OCBRA","CCBRA","IF","THEN",
"ELSE","WHILE","DO","READ","OPAR","CPAR","WRITE","COMMA","STRING","ATRIB",
"RELOP","ADDOP","MULTOP","NEGOP","CONS","TRUE","FALSE",
};
char *yyrule[] = {
"$accept : prog",
"prog : PROGRAM ID SEMIC decls compcmd DOT",
"decls : VAR decl_list",
"decls :",
"decl_list : decl_list decl_type",
"decl_list : decl_type",
"decl_type : id_list COLON type SEMIC",
"id_list : id_list COMMA ID",
"id_list : ID",
"type : INTEGER",
"type : REAL",
"type : BOOL",
"compcmd : OCBRA cmd_list CCBRA",
"cmd_list : cmd_list SEMIC cmd",
"cmd_list : cmd",
"cmd : If_cmd",
"cmd : While_cmd",
"cmd : Read_cmd",
"cmd : Write_cmd",
"cmd : Atrib_cmd",
"cmd : compcmd",
"If_cmd : IF exp THEN cmd",
"If_cmd : IF exp THEN cmd ELSE cmd",
"While_cmd : WHILE exp DO cmd",
"Read_cmd : READ OPAR id_list CPAR",
"Write_cmd : WRITE OPAR w_list CPAR",
"w_list : w_list COMMA w_elem",
"w_list : w_elem",
"w_elem : exp",
"w_elem : STRING",
"Atrib_cmd : ID ATRIB exp",
"exp : simple_exp",
"exp : simple_exp RELOP simple_exp",
"simple_exp : simple_exp ADDOP term",
"simple_exp : term",
"term : term MULTOP fac",
"term : fac",
"fac : fac NEGOP",
"fac : CONS",
"fac : RCONS",
"fac : OPAR exp CPAR",
"fac : TRUE",
"fac : FALSE",
"fac : ID",
};
#endif
#ifndef YYSTYPE
typedef int YYSTYPE;
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 128 "sinan.yacc"

#include "lex.yy.c"
#line 224 "y.tab.c"
#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate]) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 41 "sinan.yacc"
{
         printf("\n Syntactical Analisys done without erros!\n");
         
         return 0;
       }
break;
#line 373 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
