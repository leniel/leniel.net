//
//	Construction and Simulation of a Robot Arm with OpenGL
//	Copyright �2007 Leniel Braz de Oliveira Macaferi & Wellington Magalh�es Leite.
//
//  UBM COMPUTER ENGINEERING - 9TH TERM [http://www.ubm.br/]
//  This program sample was developed and turned in as a term paper for Computer Graphics
//  The source code is provided "as is" without warranty.
//
//  The original code can be found at:
//  http://www.cs.unc.edu/~dm/UNC/COMP236/Homeworks/hw1b/

using System;
using System.Windows.Forms;
using OpenGL;
using Tao.FreeGlut;

namespace ComputerGraphics
{
  /// <summary>
  /// Creates a robot arm
  /// </summary>
  class RobotArm
  {
    // Robot's arm controls
    static float baseTransX = -0.5f; // 0
    static float baseTransZ = 0;
    static float baseSpin = 0;       // 1
    static float shoulderAng = -10;  // 2
    static float elbowAng = -120;
    static float wristAng = 90;      // 3
    static float wristTwistAng = 10;
    static float fingerAng1 = 45;    // 4
    static float fingerAng2 = -90;

    // Robot's colors
    static byte[] arms = { 128, 128, 128 };
    static byte[] joints = { 0, 68, 119 };
    static byte[] fingers = { 150, 0, 24 };
    static byte[] fingerJoints = { 128, 128, 128 };

    // User interface global variables
    static bool leftButtonDown = false;    // Mouse stuff
    static float oldX, oldY, newX, newY;
    static int robotControl = 1;

    static void DrawUnitCylinder(int numSegs)  // x,y,z in [0,1], Y-axis is up
    {
      int i;
      float[] Px = new float[numSegs];
      float[] Py = new float[numSegs];
      float AngIncr = (2.0f * 3.1415927f) / (float)numSegs;
      float Ang = AngIncr;
      Px[0] = 1;

      Py[0] = 0;

      for (i = 1; i < numSegs; i++, Ang += AngIncr)
      {
        Px[i] = (float)Math.Cos(Ang);
        Py[i] = (float)Math.Sin(Ang);
      }

      GL.glMatrixMode(GL.GL_MODELVIEW);
      GL.glPushMatrix();
      GL.glTranslatef(0.5f, 0.5f, 0.5f);
      GL.glScalef(0.5f, 0.5f, 0.5f);

      // Top
      GL.glNormal3f(0, 1, 0);
      GL.glBegin(GL.GL_TRIANGLE_FAN);
      GL.glVertex3f(0, 1, 0);
      for (i = 0; i < numSegs; i++)
        GL.glVertex3f(Px[i], 1, -Py[i]);
      GL.glVertex3f(Px[0], 1, -Py[0]);
      GL.glEnd();

      // Bottom
      GL.glNormal3f(0, -1, 0);
      GL.glBegin(GL.GL_TRIANGLE_FAN);
      GL.glVertex3f(0, -1, 0);
      for (i = 0; i < numSegs; i++)
        GL.glVertex3f(Px[i], -1, Py[i]);
      GL.glVertex3f(Px[0], -1, Py[0]);
      GL.glEnd();

      // Sides
      GL.glBegin(GL.GL_QUAD_STRIP);
      for (i = 0; i < numSegs; i++)
      {
        GL.glNormal3f(Px[i], 0, -Py[i]);
        GL.glVertex3f(Px[i], 1, -Py[i]);
        GL.glVertex3f(Px[i], -1, -Py[i]);
      }
      GL.glNormal3f(Px[0], 0, -Py[0]);
      GL.glVertex3f(Px[0], 1, -Py[0]);
      GL.glVertex3f(Px[0], -1, -Py[0]);
      GL.glEnd();

      GL.glPopMatrix();
    }

    static void DrawUnitSphere(int numSegs)  // x,y,z in [0,1]
    {
      GL.glMatrixMode(GL.GL_MODELVIEW);
      GL.glPushMatrix();
      GL.glTranslatef(0.5f, 0.5f, 0.5f);
      Glut.glutSolidSphere(0.5f, numSegs, numSegs);
      GL.glPopMatrix();
    }

    static void DrawUnitCone(int numSegs)  // x,y,z in [0,1], apex is in +Y direction
    {
      GL.glMatrixMode(GL.GL_MODELVIEW);
      GL.glPushMatrix();
      GL.glTranslatef(0.5f, 0, 0.5f);
      GL.glRotatef(-90, 1, 0, 0);
      Glut.glutSolidCone(0.5f, 1, numSegs, numSegs);
      GL.glPopMatrix();
    }

    static void DrawGroundPlane(int numSegs)
    {
      GL.glColor3f(0.7f, 0.7f, 0.7f);
      GL.glBegin(GL.GL_QUADS);
      GL.glNormal3f(0f, 1f, 0f);
      GL.glVertex3f(-1f, 0f, 1f);
      GL.glVertex3f(1f, 0f, 1f);
      GL.glVertex3f(1f, 0f, -1f);
      GL.glVertex3f(-1f, 0f, -1f);
      GL.glEnd();
    }

    static void DrawJoint(int numSegs)
    {
      GL.glMatrixMode(GL.GL_MODELVIEW);
      GL.glPushMatrix();
      GL.glScalef(0.15f, 0.15f, 0.12f);
      GL.glRotatef(90, 1, 0, 0);
      GL.glTranslatef(-0.5f, -0.5f, -0.5f);
      GL.glColor3ubv(joints);
      DrawUnitCylinder(numSegs);
      GL.glPopMatrix();
    }

    static void DrawBase(int numSegs)
    {
      GL.glMatrixMode(GL.GL_MODELVIEW);
      GL.glPushMatrix();
      GL.glScalef(0.2f, 0.025f, 0.2f);
      GL.glTranslatef(-0.5f, 0, -0.5f);
      GL.glColor3ubv(joints);
      DrawUnitCylinder(numSegs);
      GL.glPopMatrix();
      GL.glPushMatrix();
      GL.glTranslatef(-0.05f, 0, -0.05f);
      GL.glScalef(0.1f, 0.4f, 0.1f);
      GL.glColor3ubv(arms);
      DrawUnitCylinder(numSegs);
      GL.glPopMatrix();
      GL.glPushMatrix();
      GL.glTranslatef(0, 0.4f, 0);
      DrawJoint(numSegs);
      GL.glPopMatrix();
    }

    static void DrawArmSegment(int numSegs)
    {
      GL.glMatrixMode(GL.GL_MODELVIEW);
      GL.glPushMatrix();
      GL.glTranslatef(-0.05f, 0, -0.05f);
      GL.glScalef(0.1f, 0.5f, 0.1f);
      GL.glColor3ubv(arms);
      DrawUnitCylinder(numSegs);
      GL.glPopMatrix();
      GL.glPushMatrix();
      GL.glTranslatef(0, 0.5f, 0);
      DrawJoint(numSegs);
      GL.glPopMatrix();
    }

    static void DrawWrist(int numSegs)
    {
      GL.glMatrixMode(GL.GL_MODELVIEW);
      GL.glPushMatrix();
      GL.glTranslatef(-0.04f, 0, -0.04f);
      GL.glScalef(0.08f, 0.2f, 0.08f);
      GL.glColor3ubv(fingers);
      DrawUnitCylinder(numSegs);
      GL.glPopMatrix();
      GL.glPushMatrix();
      GL.glTranslatef(0, 0.2f, 0);
      GL.glScalef(0.12f, 0.12f, 0.12f);
      GL.glTranslatef(-0.5f, -0.5f, -0.5f);
      GL.glColor3ubv(fingerJoints);
      DrawUnitSphere(numSegs);
      GL.glPopMatrix();
    }

    static void DrawFingerBase(int numSegs)
    {
      GL.glMatrixMode(GL.GL_MODELVIEW);
      GL.glPushMatrix();
      GL.glTranslatef(-0.025f, 0, -0.025f);
      GL.glScalef(0.05f, 0.3f, 0.05f);
      GL.glColor3ubv(fingers);
      DrawUnitCylinder(numSegs);
      GL.glPopMatrix();
      GL.glPushMatrix();
      GL.glTranslatef(0, 0.3f, 0);
      GL.glScalef(0.08f, 0.08f, 0.08f);
      GL.glTranslatef(-0.5f, -0.5f, -0.5f);
      GL.glColor3ubv(fingerJoints);
      DrawUnitSphere(numSegs);
      GL.glPopMatrix();
    }

    static void DrawFingerTip(int numSegs)
    {
      GL.glMatrixMode(GL.GL_MODELVIEW);
      GL.glPushMatrix();
      GL.glScalef(0.05f, 0.25f, 0.05f);
      GL.glTranslatef(-0.5f, 0, -0.5f);
      GL.glColor3ubv(fingers);
      DrawUnitCone(numSegs);
      GL.glPopMatrix();
    }

    static void DrawRobotArm(int numSegs)
    {
      GL.glMatrixMode(GL.GL_MODELVIEW);

      GL.glTranslatef(baseTransX, 0, baseTransZ);
      GL.glRotatef(baseSpin, 0f, 360f, 0f);
      DrawBase(64);

      GL.glTranslatef(0, 0.4f, 0);
      GL.glRotatef(shoulderAng, 0f, 0f, 90f);
      DrawArmSegment(64);

      GL.glTranslatef(0, 0.5f, 0);
      GL.glRotatef(elbowAng, 0f, 0f, 90f);
      DrawArmSegment(64);

      GL.glTranslatef(0, 0.5f, 0);
      GL.glRotatef(wristAng, 0.0f, 0f, 90f);
      DrawWrist(16);

      GL.glRotatef(wristTwistAng, 0.0f, 180f, 0f);

      GL.glPushMatrix();

      GL.glTranslatef(0f, 0.2f, 0f);
      GL.glRotatef(fingerAng1, 0f, 0f, -180f);
      DrawFingerBase(16);

      GL.glTranslatef(0f, 0.3f, 0f);
      GL.glRotatef(fingerAng2, 0f, 0f, -90f);
      DrawFingerTip(16);

      GL.glPopMatrix();

      GL.glPushMatrix();

      GL.glTranslatef(0f, 0.2f, 0f);
      GL.glRotatef(fingerAng1, 0f, 0f, 90f);
      DrawFingerBase(16);

      GL.glTranslatef(0f, 0.3f, 0);
      GL.glRotatef(fingerAng2, 0f, 0f, 90f);
      DrawFingerTip(16);

      GL.glPopMatrix();
    }

    static void myDisplay()
    {
      GL.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);

      GL.glMatrixMode(GL.GL_MODELVIEW);
      GL.glLoadIdentity();
      GLU.gluLookAt(0f, 2f, 4f, 0f, 0.5f, 0f, 0f, 1f, 0f);

      DrawGroundPlane(16);
      DrawRobotArm(16);

      Glut.glutSwapBuffers();
    }

    static void myReshape(int w, int h)
    {
      GL.glViewport(0, 0, w, h);

      GL.glMatrixMode(GL.GL_PROJECTION);
      GL.glLoadIdentity();
      GLU.gluPerspective(30, w / h, 0.1, 10);

      GL.glMatrixMode(GL.GL_MODELVIEW);
      GL.glLoadIdentity();
      GL.glTranslatef(1.0f, 0.5f, -7.0f);
    }

    static void myIdle()
    {
      Glut.glutPostRedisplay();
    }

    static void KeyboardFunc(byte Key, int x, int y)
    {
      char c = (char)Key;

      if (c >= '1' && c <= '5')
        robotControl = c - '1';
      if (Key == 27)
        Application.Exit();         // ESC
    }

    static void MouseFunc(int button, int state, int x, int y)
    {
      newX = x;
      newY = y;

      if (button == Glut.GLUT_LEFT_BUTTON)
        leftButtonDown = !leftButtonDown;
    }

    static void MotionFunc(int x, int y)
    {
      oldX = newX;
      oldY = newY;
      newX = x;
      newY = y;
      float RelX = (newX - oldX) / Glut.glutGet(Glut.GLUT_WINDOW_WIDTH);
      float RelY = (newY - oldY) / Glut.glutGet(Glut.GLUT_WINDOW_HEIGHT);
      if (leftButtonDown)
        switch (robotControl)
        {
          case 0:
            baseTransX += RelX;
            baseTransZ += RelY;
            break;
          case 1:
            baseSpin += RelX * 180;
            break;
          case 2:
            shoulderAng += RelY * -90;
            elbowAng += RelX * 90;
            break;
          case 3:
            wristAng += RelY * -180;
            wristTwistAng += RelX * 180;
            break;
          case 4:
            fingerAng1 += RelY * 90;
            fingerAng2 += RelX * 180;
            break;
        };
    }

    [STAThread]
    public static void Main(string[] args)
    {
      Glut.glutInit();
      Glut.glutInitDisplayMode(Glut.GLUT_DOUBLE | Glut.GLUT_RGB | Glut.GLUT_DEPTH);
      Glut.glutGetWindow();
      Glut.glutInitWindowSize(512, 512);
      Glut.glutInitWindowPosition(180, 100);
      Glut.glutCreateWindow("The Robot Arm");

      GL.glEnable(GL.GL_COLOR_MATERIAL);
      GL.glEnable(GL.GL_LIGHTING);
      GL.glEnable(GL.GL_LIGHT0);
      GL.glEnable(GL.GL_DEPTH_TEST);
      GL.glEnable(GL.GL_NORMALIZE);
      GL.glEnable(GL.GL_CULL_FACE);

      Glut.glutDisplayFunc(myDisplay);
      Glut.glutReshapeFunc(myReshape);
      Glut.glutIdleFunc(myIdle);

      Glut.glutKeyboardFunc(KeyboardFunc);
      Glut.glutMouseFunc(MouseFunc);
      Glut.glutMotionFunc(MotionFunc);

      Glut.glutMainLoop();
    }
  }
}
