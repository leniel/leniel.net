﻿using System.Collections.Generic;
using System.Linq;

namespace MissingNumbersFinder
{
public static class MyExtensions
{
    /// <summary>
    /// Finds the missing numbers in a list.
    /// </summary>
    /// <param name="list">List of numbers</param>
    /// <returns>Missing numbers</returns>
    public static IEnumerable<int> FindMissing(this List<int> list)
    {
        // Sorting the list
        list.Sort();

        // First number of the list
        var firstNumber = list.First();

        // Last number of the list
        var lastNumber = list.Last();

        // Range that contains all numbers in the interval
        // [ firstNumber, lastNumber ]
        var range = Enumerable.Range(firstNumber, lastNumber - firstNumber);

        // Getting the set difference of the 2 sequences:
        var missingNumbers = range.Except(list);

        return missingNumbers;
    }

    /// <summary>
    /// Finds the duplicated numbers in a list.
    /// </summary>
    /// <param name="list">List of numbers</param>
    /// <returns>Duplicated numbers</returns>
    public static IEnumerable<int> FindDuplicates(this List<int> list)
    {
        return list.
            GroupBy(i => i).
            Where(g => g.Count() > 1).
            Select(g => g.Key);
    }
}
}
