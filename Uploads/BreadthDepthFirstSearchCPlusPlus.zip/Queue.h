// Queue
struct Queue
{
  int start, end, tot;
  int info[max + 1];
};

void StartQueue(Queue *q)
{
  q->tot = 0;
  q->start = 1;
  q->end = 0;
}

int IsQueueEmpty(Queue *q)
{
  return q->tot == 0 ? 1 : 0;
}

int IsQueueFull(Queue *q)
{
  return q->tot == max ? 1 : 0;
}

int Adc(int x)
{
    return x == max ? 1 : x + 1; 
}

void Enqueue(Queue *q, int x)
{
  if(!IsQueueFull(q))
  {
    q->end = Adc(q->end);
    q->info[q->end] = x;
    q->tot++;
  }
}

int Dequeue(Queue *q)
{
  int ret = 0;

  if(!IsQueueEmpty(q))
  {
    ret = q->info[q->start];
    q->start = Adc(q->start);
    q->tot--;
  }

  return ret;
}
// End Queue