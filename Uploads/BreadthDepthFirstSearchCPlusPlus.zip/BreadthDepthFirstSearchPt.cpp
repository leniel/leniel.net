//
//	Algoritmos de busca desinformada - Exemplos de aplica��o em C++ para Busca em Largura e Busca em Profundidade
//	Copyright �2007 Leniel Braz de Oliveira Macaferi & Wellington Magalh�es Leite.
//
//  UBM Engenharia de Computa��o - 9� per�odo [http://www.ubm.br/]
//  Este programa foi entregue como trabalho da disciplina de Intelig�ncia Artificial. Utilizamos o esbo�o fornecitieso pelo professor.
//  As fun��es de Busca em Largura, Busca em Profundidade e Mostrar Caminho foram desenvolvidas por n�s.
//
//  O c�digo fonte � provido "como est�" sem garantia.
//
//  07/04/2007
//
//  Links utilizados como refer�ncia:
//  http://msdn2.microsoft.com/en-us/library/aa289152(VS.71).aspx.
//  http://ai-depot.com/Tutorial/PathFinding-Blind.html
//

#include <iostream>
#include <string>

using namespace std;

#define max 200 

// Stack
typedef struct Stack
{
  int topo;
  int info[max + 1];
};

void StartStack(Stack *s)
{
  s->topo = 0;
}

int IsStackEmpty(Stack *s)
{
  return s->topo==0 ? 1 : 0;
}

int IsStackFull(Stack *s)
{
  return s->topo == max ? 1 : 0;
}

void Push(Stack *s, int x)
{
  if(!IsStackFull(s))
  {
    s->topo++;
    s->info[s->topo] = x;
  }
}

int Pop(Stack *s)
{
  int ret = 0;

  if(!IsStackEmpty(s))
  {
    ret = s->info[s->topo];
    s->topo--;
  }

  return ret;
}
// End Stack


// Queue
typedef struct Queue
{
  int start, end, tot;
  int info[max + 1];
};

void StartQueue(Queue *q)
{
  q->tot = 0;
  q->start = 1;
  q->end = 0;
}

int IsQueueEmpty(Queue *q)
{
  return q->tot == 0 ? 1 : 0;
}

int IsQueueFull(Queue *q)
{
  return q->tot == max ? 1 : 0;
}

int Adc(int x)
{
    return x == max ? 1 : x + 1; 
}

void Enqueue(Queue *q, int x)
{
  if(!IsQueueFull(q))
  {
    q->end = Adc(q->end);
    q->info[q->end] = x;
    q->tot++;
  }
}

int Dequeue(Queue *q)
{
  int ret = 0;

  if(!IsQueueEmpty(q))
  {
    ret = q->info[q->start];
    q->start = Adc(q->start);
    q->tot--;
  }

  return ret;
}
// End Queue

// Romania map definition
char *cities[21] =
{"", "Arad", "Bucharest", "Craiova", "Dobreta", "Eforie", "Fagaras", "Giurgiu", "Hirsova", "Iasi", "Lugoj",
"Mehadia", "Neamt", "Oradea", "Pitesti", "Rimnicu Vilcea", "Sibiu", "Timisoara", "Urziceni", "Vaslui", "Zerind"};

// Adjacency matrix
int map[21][21] = {
/*    A  B  C  D  E  F  G  H  I  L  M  N  O  P  R  S  T  U  V  Z  */
  {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0},
  {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1}, // Arad           -> Sibiu, Timisoara, Zerind
  {2, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0}, // Bucharest      -> Fagaras, Giurgiu, Pitesti, Urziceni
  {3, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0}, // Craiova        -> Dobreta, Pitesti, Rimnicu Vilcea 
  {4, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // Dobreta        -> Craiova, Mehadia
  {5, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // Eforie         -> Hirsova
  {6, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}, // Fagaras        -> Bucharest, Sibiu
  {7, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // Girgiu         -> Bucharest
  {8, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}, // Hirsova        -> Eforie, Urziceni
  {9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0}, // Iasi           -> Neamt, Vaslui
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0}, // Lugoj          -> Mehadia, Timisoara
  {1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // Mehadia        -> Dobreta, Lugoj
  {2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // Neamt          -> Iasi
  {3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1}, // Oradea         -> Sibiu, Zerind
  {4, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}, // Pitesti        -> Bucharest, Craiova, Rimnicu Vilcea
  {5, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0}, // Rimnicu Vilcea -> Craiova, Pitesti, Sibiu
  {6, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0}, // Sibiu          -> Arad, Fagaras, Oradea, Rimnicu Vilcea
  {7, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // Timisoara      -> Arad, Lugoj
  {8, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}, // Urziceni       -> Bucharest, Hirsova, Vaslui
  {9, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}, // Vaslui         -> Iasi, Urziceni
  {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}  // Zerind         -> Arad, Oradea
};

int visited[21] = {0};

int parents[21] = {0};
// End Romania map definition

// Recursive funtion
void ShowPath(int u)
{
  if(parents[u] != 0)
    ShowPath(parents[u]);

  printf(" %s", cities[u]);
}

void BreadthFirstSearch(int origin, int destination)
{
  Queue *q = new Queue();

  StartQueue(q);

  Enqueue(q, origin);

  while(IsQueueEmpty(q) == 0)
  {
    int u = Dequeue(q);

    if(u == destination)
    {
      printf("Path found.");
      
      break;
    }
    else
    {
      visited[u] = 1;

      for(int v = 1; v <= 20; v++)
      {
        if(map[u][v] != 0)
        {
          if(visited[v] == 0)
          {
            visited[v] = 1;

            parents[v] = u;

            if(v != destination)
            {
              if(!IsQueueFull(q))
              {
                Enqueue(q, v);

                ShowPath(v);

                printf("\n");
              }
              else
              {
                printf("Queue full.");

                break;
              }
            }
            else
            {
              ShowPath(v);

              return;
            }
          }            
        }
      }
    }
  }
}

void DepthFirstSearch(int origin, int destination)
{
  Stack *s = new Stack();

  StartStack(s);

  Push(s, origin);

  while(IsStackEmpty(s) == 0)
  {
    int u = Pop(s);

    if(u == destination)
    {
      printf("Path found.");
      
      break;
    }
    else
    {
      visited[u] = 1;

      for(int v = 1; v <= 20; v++)
      {
        if(map[u][v] != 0)
        {
          if(visited[v] == 0)
          {
            visited[v] = 1;

            parents[v] = u;

            if(v != destination)
            {
              if(!IsStackFull(s))
              {
                Push(s, v);

                ShowPath(v);

                printf("\n");
              }
              else
              {
                printf("Stack full.");

                break;
              }
            }
            else
            {
              ShowPath(v);

              return;
            }
          }            
        }
      }
    }
  }
}

void main()
{
  int origin, destination;

  system("cls");

  printf("\n List of cities: \n");

  for(int i = 1; i <= 20; i++)
  {
    printf(" \n%2d - ", i);

    for(int j = 0; j < strlen(cities[i]); j++)
      printf("%c", cities[i][j]);
  }

  printf("\n\n Type the origin: ");
  scanf("%d", &origin);

  printf(" Type the destination: ");
  scanf("%d", &destination);

  printf("\n Breadth First Search\n\n");

  BreadthFirstSearch(origin, destination);

  for(int i = 1; i <= 20; i++)
    visited[i] = 0;

  printf("\n\n Depth First Search\n\n");

  DepthFirstSearch(origin, destination);

  cin.ignore();

  getchar();
}