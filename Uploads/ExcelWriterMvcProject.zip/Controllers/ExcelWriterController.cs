using System;
using System.IO;
using System.Web.Mvc;
using NPOI.HSSF.UserModel;
using OfficeOpenXml;

namespace ExcelWriterMvcProject.Controllers
{
    public class ExcelWriterController : Controller
    {
        /// <summary>
        /// Creates a new Excel spreadsheet based on a template using the ExcelPackage library.
        /// A new file is created on the server based on a template.
        /// </summary>
        /// <returns>Excel report</returns>
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult ExcelPackageCreate()
        {
            try
            {
                FileInfo template = new FileInfo(Server.MapPath(@"\Content\ExcelPackageTemplate.xlsx"));

                FileInfo newFile = new FileInfo(Server.MapPath(@"\Content\ExcelPackageNewFile.xlsx"));

                // Using the template to create the newFile...
                using(ExcelPackage excelPackage = new ExcelPackage(newFile, template))
                {
                    // Getting the complete workbook...
                    ExcelWorkbook myWorkbook = excelPackage.Workbook;

                    // Getting the worksheet by its name...
                    ExcelWorksheet myWorksheet = myWorkbook.Worksheets["Sheet1"];

                    // Setting the value 77 at row 5 column 1...
                    myWorksheet.Cell(5, 1).Value = 77.ToString();

                    // Saving the change...
                    excelPackage.Save();
                }

                TempData["Message"] = "Excel report created successfully!";

                return RedirectToAction("ExcelPackage");
            }
            catch(Exception ex)
            {
                TempData["Message"] = "Oops! Something went wrong.";

                return RedirectToAction("ExcelPackage");
            }
        }

        /// <summary>
        /// Creates a new Excel spreadsheet based on a template using the NPOI library.
        /// The template is changed in memory and a copy of it is sent to
        /// the user computer through a file stream.
        /// </summary>
        /// <returns>Excel report</returns>
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult NPOICreate()
        {
            try
            {
                // Opening the Excel template...
                FileStream fs =
                    new FileStream(Server.MapPath(@"\Content\NPOITemplate.xls"), FileMode.Open, FileAccess.Read);

                // Getting the complete workbook...
                HSSFWorkbook templateWorkbook = new HSSFWorkbook(fs, true);

                // Getting the worksheet by its name...
                HSSFSheet sheet = templateWorkbook.GetSheet("Sheet1");

                // Getting the row... 0 is the first row.
                HSSFRow dataRow = sheet.GetRow(4);

                // Setting the value 77 at row 5 column 1
                dataRow.GetCell(0).SetCellValue(77);

                // Forcing formula recalculation...
                sheet.ForceFormulaRecalculation = true;

                MemoryStream ms = new MemoryStream();

                // Writing the workbook content to the FileStream...
                templateWorkbook.Write(ms);

                TempData["Message"] = "Excel report created successfully!";

                // Sending the server processed data back to the user computer...
                return File(ms.ToArray(), "application/vnd.ms-excel", "NPOINewFile.xls");
            }
            catch(Exception ex)
            {
                TempData["Message"] = "Oops! Something went wrong.";

                return RedirectToAction("NPOI");
            }
        }

        public ActionResult ExcelPackage()
        {
            return View();
        }

        public ActionResult NPOI()
        {
            return View();
        }

    }
}
