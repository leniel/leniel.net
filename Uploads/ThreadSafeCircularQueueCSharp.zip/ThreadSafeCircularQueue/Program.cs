﻿//
//	C# Thread Safe Circular Queue Sample Implementation
//	Copyright ©2008 Leniel Braz de Oliveira Macaferi.
//
//  This program sample was developed and turned in for a test regarding a
//  Software Development Engineer in Test (SDTE) position at Microsoft 
//  The source code is provided "as is" without warranty.
//
//  References
//  Thread Safety articles
//  [1] Venners, Bill. Designing for Thread Safety: Using Synchronization, Immutable Objects, and Thread-Safe Wrappers. 1998.
//  Available at <http://www.artima.com/designtechniques/threadsafety.html>. Accessed on April 29, 2008.
//
//  [2] Suess, Michael. A Short Guide to Mastering Thread-Safety. 2006.
//  Available at <http://www.thinkingparallel.com/2006/10/15/a-short-guide-to-mastering-thread-safety/>. Accessed on April 29, 2008.
//
//  [3] Allen, K. Scott. Statics & Thread Safety: Part II. 2004.
//  Available at <http://www.odetocode.com/Articles/314.aspx>. Accessed on April 29, 2008.
//
//  Circular Queue sample code
//  [4] Kumar, Nunna Santhosh. Circular Queue Implementation using Arrays in C++.
//  Available at <http://www.sourcecodesworld.com/source/show.asp?ScriptID=887>. Accessed on April 29, 2008.
//
//  Thread material
//  [5] Albahari, Joseph. Threading in C#. 2007.
//  Available at <http://www.albahari.com/threading/>. Accessed on April 29, 2008.
//
//  January 2008

using System;
using System.Threading;

namespace MicrosoftSdteScreen
{
  class Program
  {
    static void Main(string[] args)
    {
      ThreadSafeCircularQueue circularQueue = new ThreadSafeCircularQueue();

      Thread[] threads = new Thread[10];

      for(int i = 0; i < threads.Length; i++)
      {
        threads[i] = new Thread(new ThreadStart(circularQueue.EnqueueDequeue));
      }

      for(int i = 0; i < threads.Length; i++)
      {
        threads[i].Start();
      }

      Console.ReadLine();
    }
  }
}