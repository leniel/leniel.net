﻿//
//	C# Thread Safe Circular Queue Sample Implementation
//	Copyright ©2008 Leniel Braz de Oliveira Macaferi.
//
//  This program sample was developed and turned in for a test regarding a
//  Software Development Engineer in Test (SDTE) position at Microsoft 
//  The source code is provided "as is" without warranty.
//
//  References
//  Thread Safety articles
//  [1] Venners, Bill. Designing for Thread Safety: Using Synchronization, Immutable Objects, and Thread-Safe Wrappers. 1998.
//  Available at <http://www.artima.com/designtechniques/threadsafety.html>. Accessed on April 29, 2008.
//
//  [2] Suess, Michael. A Short Guide to Mastering Thread-Safety. 2006.
//  Available at <http://www.thinkingparallel.com/2006/10/15/a-short-guide-to-mastering-thread-safety/>. Accessed on April 29, 2008.
//
//  [3] Allen, K. Scott. Statics & Thread Safety: Part II. 2004.
//  Available at <http://www.odetocode.com/Articles/314.aspx>. Accessed on April 29, 2008.
//
//  Circular Queue sample code
//  [4] Kumar, Nunna Santhosh. Circular Queue Implementation using Arrays in C++.
//  Available at <http://www.sourcecodesworld.com/source/show.asp?ScriptID=887>. Accessed on April 29, 2008.
//
//  Thread material
//  [5] Albahari, Joseph. Threading in C#. 2007.
//  Available at <http://www.albahari.com/threading/>. Accessed on April 29, 2008.
//
//  January 2008

using System;

namespace MicrosoftSdteScreen
{
  class ThreadSafeCircularQueue
  {
    private int[] queue;
    private int head;
    private int tail;
    private int length;

    static Object thisLock = new Object();

    public ThreadSafeCircularQueue()
    {
      Initialize();
    }

private void Initialize()
{
  head = tail = -1;

  Console.Write("Circular Queue size: ");

  string length = Console.ReadLine();

  this.length = int.Parse(length);

  queue = new int[this.length];
}

private void Enqueue(int value)
{
  lock(thisLock)
  {
    if((head == 0 && tail == length - 1) || (tail + 1 == head))
    {
      Console.WriteLine("Circular queue is full.");

      return;
    }
    else
    {
      if(tail == length - 1)
        tail = 0;
      else
        tail++;

      queue[tail] = value;

      Console.WriteLine("In -> {0}", value);
    }

    if(head == -1)
      head = 0;
  }
}

private void Dequeue()
{
  lock(thisLock)
  {
    int value;

    if(head == -1)
    {
      Console.WriteLine("Circular queue is empty.");

      value = -1;
    }
    else
    {
        value = queue[head];
      queue[head] = 0;

      if(head == tail)
        head = tail = -1;
      else
        if(head == length - 1)
          head = 0;
        else
          head++;
    }

    Console.WriteLine("Out -> {0}", value);
  }
}

private void Show()
{
  lock(thisLock)
  {
    int i;

    if(head == -1)
    {
      Console.WriteLine("Circular queue is empty.");

      return;
    }
    else
    {
      if(tail < head)
      {
        for(i = 0; i <= length - 1; i++)
          Console.Write("{0} ", queue[i]);
      }
      else
        for(i = 0; i <= tail; i++)
          Console.Write("{0} ", queue[i]);

      Console.WriteLine();
    }
  }
}

    public void EnqueueDequeue()
    {
      Enqueue(1);
      Enqueue(2);
      Enqueue(3);
      Enqueue(4);
      Show();
      Enqueue(5); // Circular queue is full!
      Dequeue();
      Dequeue();
      Dequeue();
      Dequeue();
      Dequeue(); // Circular queue is empty!
      Dequeue(); // Circular queue is empty!
      Show();
      Enqueue(6);
      Show();
      Enqueue(7);
      Show();
      Dequeue();
      Dequeue();
      Enqueue(8);
      Enqueue(9);
      Show();

      // Supposing a 4 size queue: | 0 | 0 | 0 | 0 | 
      //
      //                           | 1 | 0 | 0 | 0 | <- Enqueue 1
      //
      //                           | 1 | 2 | 0 | 0 | <- Enqueue 2
      //
      //                           | 1 | 2 | 3 | 0 | <- Enqueue 3
      //
      //                           | 1 | 2 | 3 | 4 | <- Enqueue 4
      //                       
      //                           | 1 | 2 | 3 | 4 | <- Circular queue is full when trying to enqueue 5.
      //
      //                           | 0 | 2 | 3 | 4 | <- Dequeue 1
      //
      //                           | 0 | 0 | 3 | 4 | <- Dequeue 2
      //
      //                           | 0 | 0 | 0 | 4 | <- Dequeue 3
      //                            
      //                           | 0 | 0 | 0 | 0 | <- Dequeue 4
      //
      //                           | 0 | 0 | 0 | 0 | <- Circular queue is empty when trying to dequeue.
      //
      //                           | 0 | 0 | 0 | 0 | <- Circular queue is empty when trying to dequeue.
      //
      //                           | 6 | 0 | 0 | 0 | <- Enqueue 6
      //
      //                           | 6 | 7 | 0 | 0 | <- Enqueue 7
      //
      //                           | 0 | 7 | 0 | 0 | <- Dequeue 6
      //
      //                           | 0 | 0 | 0 | 0 | <- Dequeue 7
      //
      //                           | 8 | 0 | 0 | 0 | <- Enqueue 8
      //
      //                           | 8 | 9 | 0 | 0 | <- Enqueue 9
      //
      // * 0 is set in a position when dequeueing so that it's easier to watch the queue variable.
    }
  }
}
