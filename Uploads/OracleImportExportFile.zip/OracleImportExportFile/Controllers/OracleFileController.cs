﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using OracleImportExportFile.Models;
using System.Configuration;

namespace OracleImportExportFile.Controllers
{
public class OracleFileController : Controller
{
    //
    // GET: /OracleFile/

    public ActionResult OracleFile(FormCollection formCollection)
    {
        // Handles the button that posted to the server...
        // OracleFile.aspx has 2 submit buttons.
        if (formCollection["Import"] != null)
        {
            Import();
        }
        else  if (formCollection["Export"] != null)
        {
            return Export();
        }

        return View();
    }

    /// <summary>
    /// Imports a file from the user computer to the database.
    /// </summary>
    /// <returns></returns>
    private void Import()
    {
        foreach (string fileName in Request.Files)
        {
            // Gets the file the user selected.
            HttpPostedFileBase file = Request.Files[fileName];

            if (file.ContentLength > 0)
            {
                // Getting the name of the folder in which the file will be saved on the server.
                string saveFolder = ConfigurationManager.AppSettings["saveFolder"];

                // Creating the path for the file on the server.
                string filePath = Path.Combine(Request.ServerVariables["APPL_PHYSICAL_PATH"] + saveFolder, Path.GetFileName(file.FileName));

                // Saving a copy of the user's posted file on the server.
                file.SaveAs(filePath);

                // Save the file in the database.
                // Although id isn't being used, this shows you how to get the id of the file just inserted in the database.
                int id = OracleFileModel.Import(DateTime.Now.ToString(), file.FileName, filePath, file.ContentType, file.ContentLength);

                // Deleting the file just imported so that the server disk does not get full.
                System.IO.File.Delete(filePath);

                TempData["message"] = "File imported with sucess.";
            }
        }
    }

    /// <summary>
    /// Exports a file from the database to the user's computer.
    /// </summary>
    /// <returns></returns>
    public ActionResult Export()
    {
        // Get the file from the database.
        MyFileModel file = OracleFileModel.Export();

        if (file.Content != null)
        {
            TempData["message"] = "File exported with success.";

            // Return the file to the user's computer.
            return File(file.Content, file.Type, file.Name);
        }
        else
        {
            TempData["message"] = "There's nothing to download.";

            return View("OracleFile");
        }
    }
}
}
