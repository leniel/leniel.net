﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OracleClient;
using System.Configuration;
using System.IO;
using System.Data;

namespace OracleImportExportFile.Models
{
    public class OracleFileModel
    {
        /// <summary>
        /// Imports any file to an Oracle database table that has a column of type BLOB.
        /// </summary>
        /// <param name="uploadDate">Date of upload/importation</param>
        /// <param name="fileName">File name</param>
        /// <param name="filePath">File path on the server</param>
        /// <param name="fileType">File type</param>
        /// <param name="fileSize">File size in bytes</param>
        /// <returns>Id of Row just inserted</returns>
        public static int Import(string uploadDate, string fileName, string filePath, string fileType, int fileSize)
        {
            OracleConnection connection = GetOracleConnection();
            connection.Open();

            OracleTransaction transaction;
            transaction = connection.BeginTransaction();

            OracleCommand cmd;
            cmd = connection.CreateCommand();
            cmd.Transaction = transaction;

            // Creates a temporary blob object on the database. This object will store the file content.
            cmd.CommandText = "declare xx blob; begin dbms_lob.createtemporary(xx, false, 0); :tempblob := xx; end;";
            cmd.Parameters.Add(new OracleParameter("tempblob", OracleType.Blob)).Direction = ParameterDirection.Output;
            cmd.ExecuteNonQuery();

            // Getting the content of the file...
            byte[] buffer = GetFileContent(filePath);

            // Oracle object responsible for storing the File content.
            OracleLob tempLob;
            // Assigning tempLob the blob object created on the database.
            tempLob = (OracleLob)cmd.Parameters[0].Value;
            tempLob.BeginBatch(OracleLobOpenMode.ReadWrite);
            // Writing the file content to tempLob.
            tempLob.Write(buffer, 0, buffer.Length);
            tempLob.EndBatch();

            cmd.Parameters.Clear();
            // The name of the Procedure responsible for inserting the data in the table.
            cmd.CommandText = "SP_IMPORT_FILE";
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new OracleParameter("upload_date", OracleType.VarChar)).Value = uploadDate;
            cmd.Parameters.Add(new OracleParameter("content", OracleType.Blob)).Value = tempLob;
            cmd.Parameters.Add(new OracleParameter("type", OracleType.VarChar)).Value = fileType;
            cmd.Parameters.Add(new OracleParameter("name", OracleType.VarChar)).Value = fileName;
            cmd.Parameters.Add(new OracleParameter("length", OracleType.Number)).Value = fileSize;
            cmd.Parameters.Add(new OracleParameter("id", OracleType.Number)).Direction = ParameterDirection.Output;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                transaction.Rollback();

                throw new Exception(ex.Message);
            }

            transaction.Commit();

            connection.Close();

            // Returning the Id of the row just inserted in table FILES.
            // This Id could be used to associate the file inserted with another table, for example,
            // if you had to parse the content of a spreadsheet and save each line in other table.
            return int.Parse(cmd.Parameters[4].Value.ToString());
        }

        /// <summary>
        /// Exports the last file imported to an Oracle database table that has a column of type BLOB.
        /// </summary>
        /// <returns>File</returns>
        public static MyFileModel Export()
        {
            MyFileModel file = new MyFileModel();

            OracleConnection connection = GetOracleConnection();
            connection.Open();

            OracleCommand cmd;
            cmd = connection.CreateCommand();

            // Gets the last File imported.
            cmd.CommandText = "select content, name, type from (select content, name, type from files f order by f.upload_date desc) where rownum = 1";

            byte[] fileContent;

            try
            {
                OracleDataReader reader = cmd.ExecuteReader();

                using (reader)
                {
                    reader.Read();

                    if (!reader.HasRows)
                    {
                        return file;
                    }

                    OracleLob blob = reader.GetOracleLob(0);
                    OracleString fileName = reader.GetOracleString(1);
                    OracleString fileType = reader.GetOracleString(2);

                    fileContent = new byte[blob.Length];

                    blob.Read(fileContent, 0, (int)blob.Length);

                    file.Content = fileContent;
                    file.Name = fileName.Value;
                    file.Type = fileType.Value;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            connection.Close();

            return file;
        }

        /// <summary>
        /// Gets an Oracle connection to the database.
        /// </summary>
        /// <returns>OracleConnection</returns>
        private static OracleConnection GetOracleConnection()
        {
            string user = ConfigurationManager.AppSettings["user"];
            string password = ConfigurationManager.AppSettings["password"];
            string dataSource = ConfigurationManager.AppSettings["dataSource"];

            return new OracleConnection("Data Source=" + dataSource + ";User Id=" + user + ";Password=" + password + ";");
        }

        /// <summary>
        /// Get the content of the file in byte array buffer.
        /// </summary>
        /// <param name="path">File path on the server</param>
        /// <returns>File content</returns>
        private static byte[] GetFileContent(string path)
        {
            Stream fs = File.OpenRead(path);

            byte[] buffer = new byte[fs.Length];

            int q = fs.Read(buffer, 0, Convert.ToInt32(fs.Length));

            fs.Close();

            return buffer;
        }
    }
}