#ifndef lint
static char yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#endif
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING (yyerrflag!=0)
#define YYPREFIX "yy"
#line 2 "sinan.yacc"
   #include <stdio.h>
   #include <stdlib.h>

   int c;
#line 17 "y.tab.c"
#define PROGRAM 257
#define ID 258
#define SEMIC 259
#define DOT 260
#define VAR 261
#define COLON 262
#define INTEGER 263
#define REAL 264
#define RCONS 265
#define BOOL 266
#define OCBRA 267
#define CCBRA 268
#define IF 269
#define THEN 270
#define ELSE 271
#define WHILE 272
#define DO 273
#define READ 274
#define OPAR 275
#define CPAR 276
#define WRITE 277
#define COMMA 278
#define STRING 279
#define ATRIB 280
#define RELOP 281
#define ADDOP 282
#define MULTOP 283
#define NEGOP 284
#define CONS 285
#define TRUE 286
#define FALSE 287
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    1,    2,    4,    6,    0,    8,    3,    3,    7,    7,
   12,    9,   13,   10,   10,   11,   11,   11,   15,    5,
   17,   14,   14,   19,   16,   21,   16,   23,   16,   25,
   16,   27,   16,   16,   29,   30,   18,   32,   31,   31,
   33,   34,   20,   35,   36,   22,   37,   39,   24,   41,
   38,   38,   40,   40,   42,   43,   26,   28,   45,   28,
   47,   44,   44,   49,   46,   46,   48,   48,   48,   48,
   48,   48,   48,
};
short yylen[] = {                                         2,
    0,    0,    0,    0,   10,    0,    3,    0,    2,    1,
    0,    5,    0,    4,    1,    1,    1,    1,    0,    4,
    0,    4,    1,    0,    2,    0,    2,    0,    2,    0,
    2,    0,    2,    1,    0,    0,    7,    0,    3,    0,
    0,    0,    6,    0,    0,    6,    0,    0,    6,    0,
    4,    1,    1,    1,    0,    0,    5,    1,    0,    4,
    0,    4,    1,    0,    4,    1,    2,    1,    1,    3,
    1,    1,    1,
};
short yydefred[] = {                                      0,
    1,    0,    0,    2,    0,    3,    0,    6,    0,    0,
   19,    0,   15,    0,   10,    0,    0,    4,    9,   11,
   13,   34,    0,   23,    0,    0,    0,    0,    0,    5,
    0,    0,   21,   20,   35,   25,   41,   27,   44,   29,
   47,   31,   55,   33,   16,   17,   18,    0,   14,    0,
    0,    0,    0,    0,    0,   12,   22,   73,   69,    0,
   68,   71,   72,    0,    0,    0,    0,    0,   45,   48,
   56,    0,   36,   59,   61,   64,   67,   42,    0,    0,
    0,   70,    0,    0,    0,    0,    0,    0,   54,   53,
    0,   52,   57,    0,    0,    0,    0,   43,   46,   49,
   50,   38,   37,    0,    0,   51,   39,
};
short yydgoto[] = {                                       2,
    3,    5,    9,    7,   22,   30,   14,   10,   15,   16,
   48,   31,   32,   23,   17,   24,   50,   36,   25,   38,
   26,   40,   27,   42,   28,   44,   29,   90,   51,   83,
  103,  105,   52,   87,   53,   79,   54,   91,   80,   92,
  104,   55,   81,   65,   84,   66,   85,   67,   86,
};
short yysindex[] = {                                   -252,
    0,    0, -242,    0, -250,    0, -244,    0, -241, -233,
    0, -229,    0, -233,    0, -258, -241,    0,    0,    0,
    0,    0, -253,    0, -217, -223, -215, -213, -204,    0,
 -219, -198,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0, -194,    0, -241,
 -251, -251, -208, -205, -203,    0,    0,    0,    0, -251,
    0,    0,    0, -195, -269, -211, -206, -190,    0,    0,
    0, -187,    0,    0,    0,    0,    0,    0, -233, -257,
 -251,    0, -241, -251, -251, -251, -241, -255,    0,    0,
 -236,    0,    0, -185, -191, -211, -206,    0,    0,    0,
    0,    0,    0, -257, -241,    0,    0,
};
short yyrindex[] = {                                      0,
    0,    0,    0,    0,    0,    0, -174,    0,    0,    0,
    0,    0,    0, -173,    0,    0, -231,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0, -231,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0, -156, -186, -220,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0, -231,    0,    0,    0, -231,    0,    0,    0,
    0,    0,    0, -249, -143, -171, -202,    0,    0,    0,
    0,    0,    0,    0, -231,    0,    0,
};
short yygindex[] = {                                      0,
    0,    0,    0,    0,   89,    0,    0,    0,   87,   25,
    0,    0,    0,    0,    0,  -50,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,  -49,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    2,
    0,    0,    0,   24,    0,   28,    0,   23,    0,
};
#define YYTABLESIZE 135
short yytable[] = {                                      57,
   58,   64,   68,   20,    1,   33,   58,   59,    6,   40,
   72,   74,   75,   59,   34,    4,    8,   60,   40,   21,
   99,   89,   21,   60,   13,   11,   32,   61,   62,   63,
   18,   93,   94,   61,   62,   63,   98,   24,   66,  100,
   26,  101,   28,   45,   46,   30,   47,   66,   37,   66,
   66,   35,   66,   43,  107,   66,   65,   66,   39,   49,
   66,   66,   66,   41,   56,   65,   69,   65,   65,   70,
   65,   76,   63,   65,   73,   65,   71,   77,   65,   65,
   65,   63,   78,   63,   63,  102,   63,   62,   82,   63,
   75,   63,    8,    7,   63,   63,   62,   12,   62,   62,
   19,   62,   58,   88,   62,  106,   62,   95,   97,   62,
   62,   58,   96,   58,   58,   60,   58,    0,    0,   58,
    0,   58,    0,    0,   60,    0,   60,   60,    0,   60,
    0,    0,   60,    0,   60,
};
short yycheck[] = {                                      50,
  258,   51,   52,  262,  257,  259,  258,  265,  259,  259,
   60,  281,  282,  265,  268,  258,  261,  275,  268,  278,
  276,  279,  278,  275,  258,  267,  258,  285,  286,  287,
  260,   81,   83,  285,  286,  287,   87,  269,  259,  276,
  272,  278,  274,  263,  264,  277,  266,  268,  272,  270,
  271,  269,  273,  258,  105,  276,  259,  278,  274,  258,
  281,  282,  283,  277,  259,  268,  275,  270,  271,  275,
  273,  283,  259,  276,  270,  278,  280,  284,  281,  282,
  283,  268,  273,  270,  271,  271,  273,  259,  276,  276,
  282,  278,  267,  267,  281,  282,  268,    9,  270,  271,
   14,  273,  259,   79,  276,  104,  278,   84,   86,  281,
  282,  268,   85,  270,  271,  259,  273,   -1,   -1,  276,
   -1,  278,   -1,   -1,  268,   -1,  270,  271,   -1,  273,
   -1,   -1,  276,   -1,  278,
};
#define YYFINAL 2
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 287
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"PROGRAM","ID","SEMIC","DOT",
"VAR","COLON","INTEGER","REAL","RCONS","BOOL","OCBRA","CCBRA","IF","THEN",
"ELSE","WHILE","DO","READ","OPAR","CPAR","WRITE","COMMA","STRING","ATRIB",
"RELOP","ADDOP","MULTOP","NEGOP","CONS","TRUE","FALSE",
};
char *yyrule[] = {
"$accept : prog",
"$$1 :",
"$$2 :",
"$$3 :",
"$$4 :",
"prog : PROGRAM $$1 ID $$2 SEMIC $$3 decls compcmd DOT $$4",
"$$5 :",
"decls : VAR $$5 decl_list",
"decls :",
"decl_list : decl_list decl_type",
"decl_list : decl_type",
"$$6 :",
"decl_type : id_list COLON $$6 type SEMIC",
"$$7 :",
"id_list : id_list COMMA $$7 ID",
"id_list : ID",
"type : INTEGER",
"type : REAL",
"type : BOOL",
"$$8 :",
"compcmd : OCBRA $$8 cmd_list CCBRA",
"$$9 :",
"cmd_list : cmd_list SEMIC $$9 cmd",
"cmd_list : cmd",
"$$10 :",
"cmd : $$10 If_cmd",
"$$11 :",
"cmd : $$11 While_cmd",
"$$12 :",
"cmd : $$12 Read_cmd",
"$$13 :",
"cmd : $$13 Write_cmd",
"$$14 :",
"cmd : $$14 Atrib_cmd",
"cmd : compcmd",
"$$15 :",
"$$16 :",
"If_cmd : IF $$15 exp THEN $$16 cmd Else_cmd",
"$$17 :",
"Else_cmd : ELSE $$17 cmd",
"Else_cmd :",
"$$18 :",
"$$19 :",
"While_cmd : WHILE $$18 exp DO $$19 cmd",
"$$20 :",
"$$21 :",
"Read_cmd : READ $$20 OPAR $$21 id_list CPAR",
"$$22 :",
"$$23 :",
"Write_cmd : WRITE $$22 OPAR $$23 w_list CPAR",
"$$24 :",
"w_list : w_list COMMA $$24 w_elem",
"w_list : w_elem",
"w_elem : exp",
"w_elem : STRING",
"$$25 :",
"$$26 :",
"Atrib_cmd : ID $$25 ATRIB $$26 exp",
"exp : simple_exp",
"$$27 :",
"exp : simple_exp RELOP $$27 simple_exp",
"$$28 :",
"simple_exp : simple_exp ADDOP $$28 term",
"simple_exp : term",
"$$29 :",
"term : term MULTOP $$29 fac",
"term : fac",
"fac : fac NEGOP",
"fac : CONS",
"fac : RCONS",
"fac : OPAR exp CPAR",
"fac : TRUE",
"fac : FALSE",
"fac : ID",
};
#endif
#ifndef YYSTYPE
typedef int YYSTYPE;
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 143 "sinan.yacc"

#include "lex.yy.c"
#line 279 "y.tab.c"
#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate]) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 42 "sinan.yacc"
{printf("PROGRAM "); c = 0;}
break;
case 2:
#line 44 "sinan.yacc"
{printf("%s", yytext);}
break;
case 3:
#line 46 "sinan.yacc"
{printf(";\n\n");}
break;
case 4:
#line 52 "sinan.yacc"
{printf(".");}
break;
case 5:
#line 53 "sinan.yacc"
{
         printf("\n Syntactical Analisys done without erros!\n");
         
         return 0;
       }
break;
case 6:
#line 60 "sinan.yacc"
{printf("VAR ");}
break;
case 11:
#line 68 "sinan.yacc"
{printf(":");}
break;
case 12:
#line 68 "sinan.yacc"
{printf(";\n");}
break;
case 13:
#line 71 "sinan.yacc"
{printf(", ");}
break;
case 14:
#line 71 "sinan.yacc"
{printf("%s", yytext);}
break;
case 15:
#line 72 "sinan.yacc"
{printf("%s", yytext);}
break;
case 16:
#line 75 "sinan.yacc"
{printf(" INTEGER");}
break;
case 17:
#line 76 "sinan.yacc"
{printf(" REAL");}
break;
case 18:
#line 77 "sinan.yacc"
{printf(" BOOL");}
break;
case 19:
#line 80 "sinan.yacc"
{int i; for(i = 0; i < c; i++)printf(" "); printf("{\n"); c = c + 2;}
break;
case 20:
#line 80 "sinan.yacc"
{printf("\n"); int i; for(i = 2; i < c; i++)printf(" "); printf("}"); c = c - 2;}
break;
case 21:
#line 83 "sinan.yacc"
{printf(";\n\n");}
break;
case 24:
#line 87 "sinan.yacc"
{int i; for(i = 0; i < c; i++)printf(" ");}
break;
case 26:
#line 88 "sinan.yacc"
{int i; for(i = 0; i < c; i++)printf(" ");}
break;
case 28:
#line 89 "sinan.yacc"
{int i; for(i = 0; i < c; i++)printf(" ");}
break;
case 30:
#line 90 "sinan.yacc"
{int i; for(i = 0; i < c; i++)printf(" ");}
break;
case 32:
#line 91 "sinan.yacc"
{int i; for(i = 0; i < c; i++)printf(" ");}
break;
case 35:
#line 95 "sinan.yacc"
{printf("IF ");}
break;
case 36:
#line 95 "sinan.yacc"
{printf(" THEN\n");}
break;
case 38:
#line 98 "sinan.yacc"
{printf("\n"); int i; for(i = 0; i < c; i++)printf(" "); printf("ELSE\n"); c = c + 2;}
break;
case 39:
#line 98 "sinan.yacc"
{c = c - 2;}
break;
case 41:
#line 102 "sinan.yacc"
{printf("WHILE ");}
break;
case 42:
#line 102 "sinan.yacc"
{printf(" DO\n");}
break;
case 44:
#line 105 "sinan.yacc"
{printf("READ");}
break;
case 45:
#line 105 "sinan.yacc"
{printf("(");}
break;
case 46:
#line 105 "sinan.yacc"
{printf(")");}
break;
case 47:
#line 108 "sinan.yacc"
{printf("WRITE");}
break;
case 48:
#line 108 "sinan.yacc"
{printf("(");}
break;
case 49:
#line 108 "sinan.yacc"
{printf(")");}
break;
case 50:
#line 111 "sinan.yacc"
{printf(", ");}
break;
case 54:
#line 115 "sinan.yacc"
{printf("%s", yytext);}
break;
case 55:
#line 118 "sinan.yacc"
{printf("%s ", yytext);}
break;
case 56:
#line 118 "sinan.yacc"
{printf("= ");}
break;
case 59:
#line 122 "sinan.yacc"
{printf(" %s ", yytext);}
break;
case 61:
#line 125 "sinan.yacc"
{printf(" %s ", yytext);}
break;
case 64:
#line 129 "sinan.yacc"
{printf(" %s ", yytext);}
break;
case 67:
#line 133 "sinan.yacc"
{printf(" %s", yytext);}
break;
case 68:
#line 134 "sinan.yacc"
{printf(" %s", yytext);}
break;
case 69:
#line 135 "sinan.yacc"
{printf(" %s", yytext);}
break;
case 71:
#line 137 "sinan.yacc"
{printf("TRUE ");}
break;
case 72:
#line 138 "sinan.yacc"
{printf("FALSE ");}
break;
case 73:
#line 139 "sinan.yacc"
{printf("%s", yytext);}
break;
#line 612 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
