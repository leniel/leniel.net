/**
 * @authors Rodrigo Gama (main developer)
 *          Leniel Macaferi (minor modifications and additions)
 * @year 2009
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Calendar;
import java.util.Properties;
import java.util.TimeZone;

public class PageVerificationThread implements Runnable
{
	private String				strUrl;
	private String				searchFor;
	private static Notificator	notificator	= null;
	private static Object		lock		= new Object();
	private int			        numAttempts	= 0;

	public PageVerificationThread(String strUrl, String searchFor, String[] emails)
	{
		this.strUrl = strUrl;
		this.searchFor = searchFor;

		synchronized (lock)
		{
			if(notificator == null)
			{
				notificator = new Notificator();

				// For each email, adds it to the notificator "to" list.
				for(int i = 0; i < emails.length; i++)
				{
					notificator.addDesetination(emails[i]);
				}
			}
		}
	}

	public void run()
	{
		try
		{
			URL url = new URL(strUrl);

			// Time interval to rerun the thread
			float numMinutos = 1;

			while(true)
			{
				try
				{
					Properties systemProperties = System.getProperties();
					systemProperties.put("http.proxyHost",
							"proxy.yourdomain.com");
					systemProperties.put("http.proxyPort", "3131");
					System.setProperties(systemProperties);

					URLConnection conn = url.openConnection();
					conn.setDoOutput(true);

					// Get the response content
					BufferedReader rd = new BufferedReader(
							new InputStreamReader(conn.getInputStream()));
					
					String line;
					
					StringBuilder document = new StringBuilder();

					// A calendar to configure the time
					Calendar calendar = Calendar.getInstance();
					TimeZone tz = TimeZone.getTimeZone("America/Sao_Paulo");
					calendar.setTimeZone(tz);
					calendar.add(Calendar.SECOND, 9);
					String timeStamp = calendar.getTime().toString();

					boolean error = false;

					// For each line of code contained in the response
					while((line = rd.readLine()) != null)
					{
						document.append(line + "\n");

						// If the line contains the text we're after...
						if(line.contains(searchFor))
						{// "is temporarily unavailable."))
							// {
							error = true;
						}
					}

					// System.out.println(document.toString());
					
					// If we found the token...
					if(error)
					{
						// Prints a message to the console
						System.out.println("Found " + searchFor + " on "
								+ strUrl);

						// Sends the e-mail
						notificator.notify("Found " + searchFor + " on "
								+ strUrl);

						// Writing the file to the file system with time information
						FileWriter fw = null;

						try
						{
							String dir = "C:/Documents and Settings/leniel-macaferi/Desktop/out/"
									+ strUrl.replaceAll("[^A-Za-z0-9]", "_")
									+ "/";

							File file = new File(dir);
							file.mkdirs();
							file = new File(dir
									+ timeStamp.replaceAll("[^A-Za-z0-9]", "_")
									+ ".html");
							file.createNewFile();

							fw = new FileWriter(file);
							fw.append(document);
						}
						finally
						{
							if(fw != null)
							{
								fw.flush();
								fw.close();
							}
						}
					}

					// If error we reduce the time interval
					if(error)
					{
						numMinutos = 0.5f;
					}
					else
					{
						numMinutos = 1;
					}

					try
					{
						Thread.sleep((long) (1000 * 60 * numMinutos));
					}
					catch(InterruptedException e)
					{
						e.printStackTrace();
					}

					// A counter to show us the number of attempts so far
					numAttempts++;

					System.out.println("Attempt: " + numAttempts + " on "
							+ strUrl + " at " + calendar.getTime().toString());
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
			}
		}
		catch(MalformedURLException m)
		{
			m.printStackTrace();
		}
	}
}