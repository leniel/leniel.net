/**
 * @authors Rodrigo Gama (main developer)
 *          Leniel Macaferi (minor modifications and additions)
 * @year 2009
 */

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

public class Main
{
	public static void main(String[] args) throws MalformedURLException
	{
		// URLs that will be verified
		List<String> urls = new ArrayList<String>();

		// Emails that will receive the notification
		String[] emails = new String[]
		{ "youremail@gmail.com" };

		// Checking for arguments
		if(args == null || args.length < 2 || args[0] == null)
		{
			System.out.println("Usage: <crawler.jar> <search string> <URLs>");
			System.exit(0);
		}
		else
		{
			// Printing some messages to the screen
			System.out.println("Searching for " + args[0] + "...");
			System.out.println("On:");

			// Showing the URLs that will be verified and adding them to the paths variable
			for(int i = 1; i < args.length; i++)
			{
				System.out.println(args[i]);

				urls.add(args[i]);
			}
		}

		// For each URL we create a PageVerificationThread passing to it the URL address, the token to
		// search for and the destination emails.
		for(int i = 0; i < urls.size(); i++)
		{
			Thread t = new Thread(new PageVerificationThread(urls.get(i),
					args[0], emails));
			t.start();
		}
	}
}