/**
 * @author Rodrigo Gama
 * @year 2009
 */

import java.util.ArrayList;
import java.util.List;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

public class Notificator
{
	private List<String>	to		= new ArrayList<String>();
	private String			from	= "leniel-macaferi";

	public void addDesetination(String dest)
	{
		to.add(dest);
	}

	public synchronized void notify(String message)
	{
		try
		{
			// Sends the e-mail
			MailSender.sendMail(from, to.toArray(new String[] {}), message);
		}
		catch (AddressException e)
		{
			e.printStackTrace();
		}
		catch (MessagingException e)
		{
			e.printStackTrace();
		}
	}
}
