/**
 * @authors Rodrigo Gama
 * @year 2009
 */

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MailSender
{
	public static void sendMail(String from, String[] toArray,
			String messageText) throws AddressException, MessagingException
	{
		// Get system properties
		Properties props = System.getProperties();

		// Setup mail server
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.auth", "true");

		// Get session
		Authenticator auth = new MyAuthenticator();
		Session session = Session.getDefaultInstance(props, auth);

		// Define message
		MimeMessage message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from));

		for(int i = 0; i < toArray.length; i++)
		{
			String to = toArray[i];

			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					to));
		}

		message.setSubject("The e-mail subject goes here!");
		message.setText(messageText);

		// Send message
		Transport.send(message);
	}
}

class MyAuthenticator extends Authenticator
{
	MyAuthenticator()
	{
		super();
	}

	protected PasswordAuthentication getPasswordAuthentication()
	{
		// Your e-mail username and password
		return new PasswordAuthentication("username", "password");
	}
}