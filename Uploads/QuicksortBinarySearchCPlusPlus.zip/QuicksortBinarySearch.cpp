// QuicksortBinarySearch.cpp : Defines the entry point for the console application.

//
//  QuickSort C++ Sample Application
//  Copyright �2001-2002 Microsoft Corporation. All rights reserved.
//
//  MSDN ACADEMIC ALLIANCE [http://www.msdnaa.net/]
//  This sample is part of a vast collection of resources we developed for
//  faculty members in K-12 and higher education. Visit the MSDN AA web site for more!
//  The source code is provided "as is" without warranty.
//
//  BinarySearch C++ Sample Application
//  Copyright �2005 Leniel Braz de Oliveira Macaferi & Wellington Magalh�es Leite. All rights reserved.
//
//  UBM COMPUTER ENGINEERING - 5TH SEMESTER [http://www.ubm.br/]
//  These two programs samples were presented as a coursework the the Programming Languages discipline.
//  Some additions were made into the QuickSort algorithm so that it could fit our needs.
//  The source code is provided "as is" without warranty.
//
//  6-28-2005
// 

// Include files
#include "stdafx.h"
#include <conio.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <time.h>

// Function prototypes
void Menu(void);
void QuickSort(char** szArray, int nLower, int nUpper);
int Partition(char** szArray, int nLower, int nUpper);
int BinarySearch(char** szArray, char key[], int nLower, int nUpper);

// Application initialization
void main(void)
{
  char op;

  do
  {
    Menu();
    printf("\n\nDo you wanna a new QuickSort? Y/N");
    op = getche();
    if(islower(op))
      op = toupper(op);
  }
  while(op == 'Y');
}

void Menu(void)
{
  // Clear screen
  system("CLS");

  // Control execution time
  clock_t initial, final;

  // Print startup banner
  printf("\nQuickSort C++ Sample Application\n");
  printf("Copyright (c)2001-2002 Microsoft Corporation. All rights reserved.\n\n");
  printf("MSDN ACADEMIC ALLIANCE [http://www.msdnaa.net/]\n\n");
  printf("BinarySearch C++ Sample Application\n");
  printf("Copyright (c)2005 Leniel Braz de Oliveira Macaferi & Wellington Magalhaes Leite.\n");
  printf("UBM COMPUTER ENGINEERING - 5TH SEMESTER [http://www.ubm.br/]\n\n");

  // Describe program function
  printf("This program example demonstrates the QuickSort and BinarySearch algorithms by\n");
  printf("reading an input file, sorting its contents, writing them to a new file and\n");
  printf("searching on them.\n\n");

  // Prompt user for filenames
  char szSrcFile[1024], szDestFile[1024];
  printf("Source: ");
  gets(szSrcFile);
  printf("Output: ");
  gets(szDestFile);

  // Read contents of source file
  const long nGrow = 8;
  long nAlloc = nGrow;
  long nSize = 0;
  char** szContents = new char* [nAlloc];
  char szSrcLine[1024];
  FILE* pStream = fopen(szSrcFile, "rt");

  while(fgets(szSrcLine, 1024, pStream))
  {
    // Trim newline character
    char* pszCheck = szSrcLine;
    while(*pszCheck != '\0')
    {
      if(*pszCheck == '\n' && *(pszCheck + 1) == '\0')
        *pszCheck = '\0';
      pszCheck++;
    }

    // Append to array
    szContents[nSize] = new char [strlen(szSrcLine) + 1];
    strcpy(szContents[nSize], szSrcLine);
    nSize = nSize + 1;

    if(nSize % nGrow == 0)
    {
      // Resize the array
      char** szPrev = szContents;
      nAlloc += nGrow;
      szContents = new char* [nAlloc];
      memcpy(szContents, szPrev, nSize * sizeof(char*));
      delete szPrev;
    }
  }
  fclose (pStream);

  initial = clock();

  // Pass to QuickSort function
  QuickSort(szContents, 0, nSize - 1);

  final = clock();

  // Write sorted lines
  pStream = fopen (szDestFile, "wt");
  for(int nIndex = 0; nIndex < nSize; nIndex++)
  {
    // Write line to output file
    fprintf (pStream, "%s\n", szContents[nIndex]);
  }
  fclose (pStream);

  // Report program success
  printf("\nThe sorted lines have been written to the output file.\n\n");

  // QuickSort execution time
  double duration = (double)(final - initial) / CLOCKS_PER_SEC;

  printf("The QuickSort execution time was: %2.9lf s = %.0lf ms = %.0lf \xE6s\n\n", duration, duration * 1000, duration * 1000000);

  char op = '\0';

  do
  {
    printf("Do you wanna a BinarySearch to locate a specific key? Y/N");

    op = getche();
    if(islower(op))
      op = toupper(op);
    if(op == 'Y')
    {
      printf("\n\nType the key you want to search for: ");
      char key[1024];
      gets(key);

      initial = clock();

      if(BinarySearch(szContents, key, 0, nSize - 1))
      {
        final = clock();

        duration = (double)(final - initial) / CLOCKS_PER_SEC;

        printf("\nKey found!\n\n");

        printf("The BinarySearch execution time was: %2.9lf s = %.0lf ms = %.0lf \xE6s\n\n", duration, duration * 1000, duration * 1000000);

      }
      else
      {
        final = clock();

        duration = (double)(final - initial) / CLOCKS_PER_SEC;

        printf("\nKey not found!\n\n");

        printf("The BinarySearch execution time was: %2.9lf s = %.0lf ms = %.0lf \xE6s\n\n", duration, duration * 1000, duration * 1000000);

      }
    }
    else
    {
      // Deallocate entire array
      for(int nIndex = 0; nIndex < nSize; nIndex++)
        // Delete current array element
        delete szContents[nIndex];

      delete szContents;
      szContents = NULL;
    }
  }
  while(op == 'Y');  
}

// QuickSort implementation
void QuickSort(char** szArray, int nLower, int nUpper)
{
  // Check for non-base case
  if(nLower < nUpper)
  {
    // Split and sort partitions
    int nSplit = Partition(szArray, nLower, nUpper);
    QuickSort(szArray, nLower, nSplit - 1);
    QuickSort(szArray, nSplit + 1, nUpper);
  }
}

// QuickSort partition implementation
int Partition (char** szArray, int nLower, int nUpper)
{
  // Pivot with first element
  int nLeft = nLower + 1;
  char* szPivot = szArray[nLower];
  int nRight = nUpper;

  // Partition array elements
  char* szSwap;
  while(nLeft <= nRight)
  {
    // Find item out of place
    while(nLeft <= nRight && strcmp (szArray[nLeft], szPivot) <= 0)
      nLeft = nLeft + 1;
    while (nLeft <= nRight && strcmp (szArray[nRight], szPivot) > 0)
      nRight = nRight - 1;

    // Swap values if necessary
    if(nLeft < nRight)
    {
      szSwap = szArray[nLeft];
      szArray[nLeft] = szArray[nRight];
      szArray[nRight] = szSwap;
      nLeft = nLeft + 1;
      nRight = nRight - 1;
    }
  }

  // Move pivot element
  szSwap = szArray[nLower];
  szArray[nLower] = szArray[nRight];
  szArray[nRight] = szSwap;
  return nRight;
}

int BinarySearch(char** szArray, char key[], int nLower, int nUpper)
{
  // Termination case
  if(nLower > nUpper)
    return 0;

  int middle = (nLower + nUpper) / 2;

  if(strcmp(szArray[middle], key) == 0)
    return middle;
  else
  {
    if(strcmp(szArray[middle], key) > 0)
      // Search left
      return BinarySearch(szArray, key, nLower, middle - 1);
    // Search right
    return BinarySearch(szArray, key, middle + 1, nUpper);
  }
}

