﻿using System.Web.Mvc;

namespace Controllers
{
    public class HomeController : Controller
    {

        [ControllerAction]
        public void Index()
        {
            RenderView("Index");
        }
    }
}
