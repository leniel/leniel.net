﻿using System.Web.Mvc;

namespace Controllers
{
    public class HelloWorldController : Controller
    {
        [ControllerAction]
        public void HiThere(string id)
        {
            ViewData["Name"] = id;
            RenderView("HelloWorld");
        }
    }
}
